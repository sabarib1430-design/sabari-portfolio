export interface Skill {
  name: string;
  category: 'Programming' | 'Frontend' | 'Database' | 'Tools';
  percentage: number;
}

export interface TimelineEvent {
  id: string;
  title: string;
  subtitle: string;
  institutionOrCompany: string;
  durationOrStatus: string;
  description: string;
  extraInfo?: string;
}

export interface Certification {
  id: string;
  title: string;
  issuer: string;
  issueDate: string;
  badgeColor: 'blue' | 'green' | 'purple';
  credentialUrl?: string;
}

export interface Service {
  id: string;
  title: string;
  description: string;
  iconName: string;
}

export interface Project {
  id: string;
  title: string;
  description: string;
  thumbnailUrl: string;
  technologies: string[];
  githubUrl: string;
  demoUrl: string;
  category: 'React' | 'Java' | 'AI' | 'Web' | 'All';
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  category: string;
  date?: string;
}

export interface GitHubStats {
  username: string;
  starsCount: number;
  forksCount: number;
  totalRepos: number;
  streakDays: number;
  contributionsCount: number;
}
