import { Skill, TimelineEvent, Certification, Service, Project, Achievement } from './types';

export const PERSONAL_INFO = {
  name: 'Sabari B',
  title: 'Computer Science Student',
  roles: [
    'Full Stack Developer',
    'React Developer',
    'AI Enthusiast',
    'Backend Developer',
    'Cybersecurity Learner'
  ],
  introduction: 'I am passionate about creating modern web applications, exploring Artificial Intelligence, Machine Learning, and Cybersecurity while continuously improving my software development skills.',
  resumeUrl: '#', // We will implement modal-view/custom interaction for View Resume and Download
  socials: {
    github: 'https://github.com/sabarib1430-design',
    linkedin: 'https://www.linkedin.com/in/sabari-b-074795398',
    email: 'mailto:sabarib1430@gmail.com',
    phone: 'tel:+917845135069',
    location: 'Salem, Tamil Nadu, India'
  }
};

export const SKILLS: Skill[] = [
  // Programming
  { name: 'C', category: 'Programming', percentage: 85 },
  { name: 'Java', category: 'Programming', percentage: 90 },
  { name: 'JavaScript', category: 'Programming', percentage: 88 },
  // Frontend
  { name: 'HTML', category: 'Frontend', percentage: 95 },
  { name: 'CSS', category: 'Frontend', percentage: 90 },
  { name: 'React', category: 'Frontend', percentage: 87 },
  // Database
  { name: 'MongoDB', category: 'Database', percentage: 80 },
  // Tools
  { name: 'VS Code', category: 'Tools', percentage: 92 },
  { name: 'Git', category: 'Tools', percentage: 85 },
  { name: 'GitHub', category: 'Tools', percentage: 88 }
];

export const EDUCATION: TimelineEvent[] = [
  {
    id: 'edu-1',
    title: 'Bachelor of Engineering',
    subtitle: 'Computer Science & Engineering',
    institutionOrCompany: 'AVS Engineering College',
    durationOrStatus: 'Third Year',
    description: 'Currently pursuing 3rd Year B.E. CSE at AVS Engineering College. Consistently maintaining academic excellence and focusing on core software engineering principles, algorithms, and practical software creation.',
    extraInfo: 'CGPA: 8.8 / 10'
  }
];

export const EXPERIENCE: TimelineEvent[] = [
  {
    id: 'exp-1',
    title: 'Freelancing',
    subtitle: 'Full Stack & Responsive Web Developer',
    institutionOrCompany: 'Self-Employed',
    durationOrStatus: 'Open for Projects',
    description: 'Open to freelance web development projects and building highly functional, clean, and responsive websites for clients.',
    extraInfo: 'Tailwind, React, Node.js'
  },
  {
    id: 'exp-2',
    title: 'Part-Time Learning',
    subtitle: 'Technical Skill Development',
    institutionOrCompany: 'Independent Study',
    durationOrStatus: 'Continuous',
    description: 'Continuously improving technical skills through practical development, active participation in coding environments, and personal hands-on projects.'
  },
  {
    id: 'exp-3',
    title: 'Internship Search',
    subtitle: 'Aspiring Intern',
    institutionOrCompany: 'Ready to Join',
    durationOrStatus: 'Looking for Opportunities',
    description: 'Looking for internship opportunities to gain industry experience, collaborate with engineering teams, and solve enterprise-level challenges.'
  }
];

export const CERTIFICATIONS: Certification[] = [
  {
    id: 'cert-1',
    title: 'Python Certification',
    issuer: 'Guvi / NPTEL / IBM Cognitive Class',
    issueDate: '2025',
    badgeColor: 'blue'
  },
  {
    id: 'cert-2',
    title: 'Cybersecurity Certification',
    issuer: 'Cisco Networking Academy / Google Coursera',
    issueDate: '2025',
    badgeColor: 'purple'
  }
];

export const SERVICES: Service[] = [
  {
    id: 'srv-1',
    title: 'Full Stack Development',
    description: 'End-to-end modern web systems built with reliable backends and stunning interactive user interfaces.',
    iconName: 'Layers'
  },
  {
    id: 'srv-2',
    title: 'Frontend Development',
    description: 'Visually brilliant, state-driven, lightning-fast client interfaces with smooth animations.',
    iconName: 'Layout'
  },
  {
    id: 'srv-3',
    title: 'Backend Development',
    description: 'Scalable databases, logical APIs, and reliable security patterns that hold up your applications.',
    iconName: 'Cpu'
  },
  {
    id: 'srv-4',
    title: 'UI/UX Design',
    description: 'Creating high-fidelity wireframes, interactive user experiences, and layouts designed to engage.',
    iconName: 'Figma'
  },
  {
    id: 'srv-5',
    title: 'Responsive Web Dev',
    description: 'Ensuring your web experience is flawless across standard desktop monitors, tablets, and smartphones.',
    iconName: 'Smartphone'
  },
  {
    id: 'srv-6',
    title: 'Portfolio Website Dev',
    description: 'Bespoke showcase websites designed for developers, students, and businesses looking to make an impact.',
    iconName: 'Briefcase'
  }
];

export const PROJECTS: Project[] = [
  {
    id: 'proj-1',
    title: 'Personal Portfolio Website',
    description: 'A premium, highly interactive glassmorphic developer portfolio. Features custom-built interactive layout filters, simulated live GitHub metrics, and a sleek cyberpunk timeline.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1507238691740-187a5b1d37b8?w=600&auto=format&fit=crop&q=60',
    technologies: ['React', 'TypeScript', 'Tailwind CSS', 'Motion'],
    githubUrl: 'https://github.com/sabarib1430-design/portfolio',
    demoUrl: '#',
    category: 'React'
  },
  {
    id: 'proj-2',
    title: 'Student Management System',
    description: 'A robust educational portal to keep track of students, courses, grading curves, and attendance. Employs modular architecture with secure backend operations.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1434030216411-0b793f4b4173?w=600&auto=format&fit=crop&q=60',
    technologies: ['Java', 'Swing', 'JDBC', 'MySQL'],
    githubUrl: 'https://github.com/sabarib1430-design/student-management',
    demoUrl: '#',
    category: 'Java'
  },
  {
    id: 'proj-3',
    title: 'AI Chatbot Assistant',
    description: 'An interactive conversational partner leveraging advanced language models to solve coding problems, draft emails, and simulate educational mentoring sessions.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1531747118685-ca8fa6e08806?w=600&auto=format&fit=crop&q=60',
    technologies: ['React', 'Node.js', 'Google Gemini API', 'Tailwind CSS'],
    githubUrl: 'https://github.com/sabarib1430-design/ai-chatbot',
    demoUrl: '#',
    category: 'AI'
  },
  {
    id: 'proj-4',
    title: 'Dynamic Weather App',
    description: 'A real-time atmospheric forecast interface pulling active climate details globally. Showcases smooth graphical transitions, geolocation tracking, and ambient themed backdrops.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1504608524841-42fe6f032b4b?w=600&auto=format&fit=crop&q=60',
    technologies: ['React', 'OpenWeather API', 'CSS Transitions', 'Tailwind'],
    githubUrl: 'https://github.com/sabarib1430-design/weather-app',
    demoUrl: '#',
    category: 'React'
  },
  {
    id: 'proj-5',
    title: 'Task Management System',
    description: 'A customized interactive board designed to organize daily projects, set deadlines, filter priorities, and track developmental milestones via local state buffers.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1484417894907-623942c8ea29?w=600&auto=format&fit=crop&q=60',
    technologies: ['React', 'LocalStorage', 'CSS Grid', 'Tailwind CSS'],
    githubUrl: 'https://github.com/sabarib1430-design/task-manager',
    demoUrl: '#',
    category: 'React'
  },
  {
    id: 'proj-6',
    title: 'Cybersecurity Awareness Portal',
    description: 'An interactive handbook and quiz hub to spread awareness about common cyber threats: phishing, brute force attacks, social engineering, and best password practices.',
    thumbnailUrl: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=600&auto=format&fit=crop&q=60',
    technologies: ['HTML5', 'CSS3', 'JavaScript', 'Responsive Grid'],
    githubUrl: 'https://github.com/sabarib1430-design/cybersecurity-awareness',
    demoUrl: '#',
    category: 'Web'
  }
];

export const ACHIEVEMENTS: Achievement[] = [
  {
    id: 'ach-1',
    title: 'Coding Competitions',
    description: 'Successfully solved complex algorithmic challenges and competitive problems across platforms like LeetCode and HackerRank, maintaining a regular streak.',
    category: 'Algorithmic Problem Solving'
  },
  {
    id: 'ach-2',
    title: 'Hackathons Participation',
    description: 'Collaborated in fast-paced software hackathons to ideate and deliver fully functional prototypes within strict time constraints.',
    category: 'Rapid Prototyping'
  },
  {
    id: 'ach-3',
    title: 'Paper Presentations',
    description: 'Prepared and delivered presentations on modern emerging technologies, cloud structures, and future computing trends.',
    category: 'Technical Communication'
  },
  {
    id: 'ach-4',
    title: 'Technical Workshops',
    description: 'Actively participated in comprehensive hands-on workshops targeting Artificial Intelligence, Cloud Services, and Cybersecurity networks.',
    category: 'Emerging Tech Exploration'
  },
  {
    id: 'ach-5',
    title: 'Learning Journey Milestone',
    description: 'Created multiple live open-source web layouts and mini-tools to cement and exercise ongoing computer science concepts.',
    category: 'Self-Driven Progress'
  }
];
