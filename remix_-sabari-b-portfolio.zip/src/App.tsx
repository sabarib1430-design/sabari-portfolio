import { useState, useEffect } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import AboutMe from './components/AboutMe';
import Skills from './components/Skills';
import Timeline from './components/Timeline';
import Services from './components/Services';
import Projects from './components/Projects';
import Achievements from './components/Achievements';
import GitHubStats from './components/GitHubStats';
import ResumeSection from './components/ResumeSection';
import Contact from './components/Contact';
import Footer from './components/Footer';
import CursorGlow from './components/CursorGlow';
import BackToTop from './components/BackToTop';

export default function App() {
  const [darkMode, setDarkMode] = useState(true);
  const [activeSection, setActiveSection] = useState('home');

  // Sync dark class with document element
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      document.body.style.backgroundColor = '#050816';
    } else {
      document.documentElement.classList.remove('dark');
      document.body.style.backgroundColor = '#f8fafc';
    }
  }, [darkMode]);

  // Scroll active section spy
  useEffect(() => {
    const handleScroll = () => {
      const sections = ['home', 'about', 'skills', 'journey', 'services', 'projects', 'achievements', 'stats', 'contact'];
      const scrollPos = window.scrollY + 200;

      for (const section of sections) {
        const el = document.getElementById(section);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPos >= top && scrollPos < top + height) {
            setActiveSection(section);
            break;
          }
        }
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <div className={`min-h-screen relative overflow-x-hidden ${
      darkMode ? 'text-white' : 'text-slate-800'
    }`}>
      
      {/* Absolute floating atmospheric gradients (background) */}
      {darkMode && (
        <div className="absolute inset-0 pointer-events-none overflow-hidden -z-20">
          <div className="absolute top-[10%] left-[5%] w-[40vw] h-[40vw] bg-blue-600/5 dark:bg-blue-600/10 rounded-full blur-[120px]" />
          <div className="absolute top-[40%] right-[10%] w-[35vw] h-[35vw] bg-purple-600/5 dark:bg-purple-600/10 rounded-full blur-[120px]" />
          <div className="absolute top-[75%] left-[12%] w-[42vw] h-[42vw] bg-emerald-600/5 dark:bg-emerald-600/8 rounded-full blur-[120px]" />
        </div>
      )}

      {/* Header Navigation */}
      <Header
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        activeSection={activeSection}
      />

      {/* Primary Main Content */}
      <main className="relative">
        
        {/* Hero Landing */}
        <section id="home-section" className="scroll-mt-12">
          <Hero darkMode={darkMode} />
        </section>

        {/* Section Divider Line with Cyberpunk node */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`h-[1px] w-full ${darkMode ? 'bg-white/10' : 'bg-slate-200'}`} />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-3 h-3 rounded-full bg-blue-500 border border-white animate-ping" />
        </div>

        {/* About Section */}
        <section id="about" className="scroll-mt-20">
          <AboutMe darkMode={darkMode} />
        </section>

        {/* Section Divider Line */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`h-[1px] w-full ${darkMode ? 'bg-white/10' : 'bg-slate-200'}`} />
        </div>

        {/* Skills Section */}
        <section id="skills" className="scroll-mt-20">
          <Skills darkMode={darkMode} />
        </section>

        {/* Section Divider Line */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`h-[1px] w-full ${darkMode ? 'bg-white/10' : 'bg-slate-200'}`} />
        </div>

        {/* Timeline Journey Section */}
        <section id="journey" className="scroll-mt-20">
          <Timeline darkMode={darkMode} />
        </section>

        {/* Section Divider Line */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`h-[1px] w-full ${darkMode ? 'bg-white/10' : 'bg-slate-200'}`} />
        </div>

        {/* Services Section */}
        <section id="services" className="scroll-mt-20">
          <Services darkMode={darkMode} />
        </section>

        {/* Section Divider Line */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`h-[1px] w-full ${darkMode ? 'bg-white/10' : 'bg-slate-200'}`} />
        </div>

        {/* Projects Showcase */}
        <section id="projects" className="scroll-mt-20">
          <Projects darkMode={darkMode} />
        </section>

        {/* Section Divider Line */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`h-[1px] w-full ${darkMode ? 'bg-white/10' : 'bg-slate-200'}`} />
        </div>

        {/* Achievements Section */}
        <section id="achievements" className="scroll-mt-20">
          <Achievements darkMode={darkMode} />
        </section>

        {/* Section Divider Line */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`h-[1px] w-full ${darkMode ? 'bg-white/10' : 'bg-slate-200'}`} />
        </div>

        {/* GitHub Statistics Section */}
        <section id="stats" className="scroll-mt-20">
          <GitHubStats darkMode={darkMode} />
        </section>

        {/* Section Divider Line */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`h-[1px] w-full ${darkMode ? 'bg-white/10' : 'bg-slate-200'}`} />
        </div>

        {/* Resume View / Download Section */}
        <section id="resume" className="scroll-mt-20">
          <ResumeSection darkMode={darkMode} />
        </section>

        {/* Section Divider Line */}
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className={`h-[1px] w-full ${darkMode ? 'bg-white/10' : 'bg-slate-200'}`} />
        </div>

        {/* Contact Form & direct details */}
        <section id="contact" className="scroll-mt-20">
          <Contact darkMode={darkMode} />
        </section>

      </main>

      {/* Footer copyright and references */}
      <Footer darkMode={darkMode} />

      {/* Interactive Floating Micro-indicators */}
      <CursorGlow />
      <BackToTop />

    </div>
  );
}
