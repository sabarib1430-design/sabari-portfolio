import { ACHIEVEMENTS } from '../data';
import { Trophy, Award, BookOpen, Presentation, Calendar, Star } from 'lucide-react';

interface AchievementsProps {
  darkMode: boolean;
}

export default function Achievements({ darkMode }: AchievementsProps) {
  // Mapping categories to nice corresponding icons
  const getIcon = (title: string) => {
    const lowercase = title.toLowerCase();
    if (lowercase.includes('coding')) {
      return <Trophy className="w-8 h-8 text-yellow-500" />;
    } else if (lowercase.includes('hackathon')) {
      return <Award className="w-8 h-8 text-purple-500" />;
    } else if (lowercase.includes('paper')) {
      return <Presentation className="w-8 h-8 text-blue-500" />;
    } else if (lowercase.includes('workshop')) {
      return <Calendar className="w-8 h-8 text-emerald-500" />;
    } else {
      return <BookOpen className="w-8 h-8 text-pink-500" />;
    }
  };

  return (
    <section id="achievements" className="py-24 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute top-1/3 right-10 w-96 h-96 bg-purple-500/5 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-yellow-500 font-mono text-sm tracking-widest uppercase px-3 py-1 rounded-full bg-yellow-500/10 border border-yellow-500/20">
            Success & Milestones
          </span>
          <h2 className={`text-3xl sm:text-4xl font-extrabold mt-4 tracking-tight ${
            darkMode ? 'text-white' : 'text-slate-900'
          }`}>
            My Key{' '}
            <span className="bg-gradient-to-r from-yellow-400 via-orange-500 to-pink-500 bg-clip-text text-transparent">
              Achievements
            </span>
          </h2>
          <p className={`mt-4 max-w-2xl mx-auto text-sm sm:text-base ${
            darkMode ? 'text-slate-400' : 'text-slate-600'
          }`}>
            Recognitions and learning milestones accomplished during academic hackathons, campus presentations, and workshops.
          </p>
        </div>

        {/* Bento/Grid Achievements Layout */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {ACHIEVEMENTS.map((ach, i) => {
            // Visual accent borders
            const accents = [
              'hover:border-yellow-500/40',
              'hover:border-purple-500/40',
              'hover:border-blue-500/40',
              'hover:border-emerald-500/40',
              'hover:border-pink-500/40',
            ];

            return (
              <div
                key={ach.id}
                className={`rounded-2xl p-6 border text-left flex flex-col justify-between transition-all duration-300 hover:scale-[1.03] hover:shadow-xl group relative overflow-hidden ${
                  darkMode
                    ? 'bg-slate-900/40 border-white/10 shadow-black/30'
                    : 'bg-white border-slate-200 shadow-slate-100/50'
                } ${accents[i % accents.length]}`}
              >
                {/* Decorative background number */}
                <span className="absolute -bottom-8 -right-4 font-black text-9xl text-slate-500/5 dark:text-white/5 select-none font-mono">
                  0{i + 1}
                </span>

                <div className="relative z-10">
                  {/* Icon Block */}
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 transition-transform duration-300 group-hover:scale-110 ${
                    darkMode ? 'bg-white/5' : 'bg-slate-100'
                  }`}>
                    {getIcon(ach.title)}
                  </div>

                  {/* Tag category */}
                  <span className={`text-[10px] font-mono font-bold uppercase tracking-wider px-2 py-0.5 rounded ${
                    darkMode ? 'bg-white/5 text-slate-400' : 'bg-slate-100 text-slate-500'
                  }`}>
                    {ach.category}
                  </span>

                  {/* Title */}
                  <h3 className={`text-lg font-bold mt-3 mb-2 tracking-tight ${darkMode ? 'text-white' : 'text-slate-800'}`}>
                    {ach.title}
                  </h3>

                  {/* Description */}
                  <p className={`text-sm leading-relaxed ${
                    darkMode ? 'text-slate-300' : 'text-slate-600'
                  }`}>
                    {ach.description}
                  </p>
                </div>

                {/* Micro-interaction star indicator */}
                <div className="mt-6 pt-4 border-t border-slate-200/50 dark:border-white/5 flex items-center justify-between text-xs font-mono text-slate-400 relative z-10">
                  <span className="flex items-center gap-1">
                    <Star className="w-3.5 h-3.5 text-yellow-500 fill-yellow-500" />
                    Verified Milestone
                  </span>
                  <span className="text-slate-500">2026</span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Mini Quote Banner */}
        <div className={`mt-12 rounded-2xl p-6 border text-center relative overflow-hidden ${
          darkMode ? 'bg-slate-950/40 border-white/5' : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="absolute top-0 bottom-0 left-0 w-1 bg-gradient-to-b from-yellow-500 to-pink-500" />
          <p className={`text-sm italic font-medium leading-relaxed max-w-3xl mx-auto ${
            darkMode ? 'text-slate-300' : 'text-slate-700'
          }`}>
            "The secret of change is to focus all of your energy, not on fighting the old, but on building the new." — Socrates. My goal is to build secure systems that help and empower communities.
          </p>
        </div>

      </div>
    </section>
  );
}
