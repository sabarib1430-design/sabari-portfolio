import { useState, useEffect } from 'react';
import { Github, Linkedin, Mail, ArrowRight, Download, Laptop, FileText, Code2, ShieldAlert, Cpu } from 'lucide-react';
import { motion } from 'motion/react';
import { PERSONAL_INFO } from '../data';

interface HeroProps {
  darkMode: boolean;
}

export default function Hero({ darkMode }: HeroProps) {
  const [typedText, setTypedText] = useState('');
  const [roleIndex, setRoleIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);

  const roles = PERSONAL_INFO.roles;

  useEffect(() => {
    let timer: NodeJS.Timeout;
    const currentRole = roles[roleIndex];
    const typingSpeed = isDeleting ? 40 : 100;

    if (!isDeleting && typedText === currentRole) {
      // Pause at full word
      timer = setTimeout(() => setIsDeleting(true), 2000);
    } else if (isDeleting && typedText === '') {
      setIsDeleting(false);
      setRoleIndex((prev) => (prev + 1) % roles.length);
    } else {
      timer = setTimeout(() => {
        setTypedText(
          isDeleting
            ? currentRole.substring(0, typedText.length - 1)
            : currentRole.substring(0, typedText.length + 1)
        );
      }, typingSpeed);
    }

    return () => clearTimeout(timer);
  }, [typedText, isDeleting, roleIndex, roles]);

  return (
    <section
      id="home"
      className="relative min-h-screen flex items-center justify-center pt-24 overflow-hidden"
    >
      {/* Dynamic Grid Background with Glow effects */}
      <div className="absolute inset-0 z-0 overflow-hidden">
        <div className={`absolute inset-0 opacity-20 ${
          darkMode
            ? 'bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)]'
            : 'bg-[linear-gradient(rgba(0,0,0,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(0,0,0,0.03)_1px,transparent_1px)]'
        } bg-[size:40px_40px]`} />

        {/* Dynamic Colorful Glowing Orbs */}
        <div className="absolute top-1/4 left-10 w-96 h-96 bg-blue-500/10 dark:bg-blue-500/15 rounded-full blur-3xl animate-pulse-slow" />
        <div className="absolute bottom-1/4 right-10 w-96 h-96 bg-purple-500/10 dark:bg-purple-500/15 rounded-full blur-3xl animate-pulse-slow" style={{ animationDelay: '2s' }} />
        <div className="absolute top-1/3 right-1/4 w-80 h-80 bg-pink-500/5 dark:bg-pink-500/10 rounded-full blur-3xl animate-pulse-slow" style={{ animationDelay: '1s' }} />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full z-10 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
          
          {/* Left Text Content */}
          <div className="lg:col-span-7 flex flex-col space-y-6 text-left">
            <div className="inline-flex items-center space-x-2">
              <span className="h-[2px] w-8 bg-blue-500 rounded-full" />
              <span className="text-blue-500 font-semibold text-sm tracking-wider uppercase">
                Welcome to my digital space
              </span>
            </div>

            <div className="space-y-3">
              <span className={`text-xl font-medium tracking-tight ${
                darkMode ? 'text-slate-300' : 'text-slate-600'
              }`}>
                Hello, I'm
              </span>
              <h1 className="text-5xl sm:text-6xl md:text-7xl font-extrabold tracking-tight">
                <span className="bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
                  {PERSONAL_INFO.name}
                </span>
              </h1>
            </div>

            {/* Dynamic Role / Subtitle cycling text */}
            <div className="h-10 flex items-center">
              <span className={`text-lg sm:text-xl md:text-2xl font-mono flex items-center ${
                darkMode ? 'text-emerald-400' : 'text-emerald-600'
              }`}>
                <span>{`> `}</span>
                <span className="ml-2 font-semibold">{typedText}</span>
                <span className="ml-1 w-[3px] h-6 bg-emerald-400 animate-pulse" />
              </span>
            </div>

            <p className={`text-base sm:text-lg max-w-2xl leading-relaxed ${
              darkMode ? 'text-slate-300' : 'text-slate-600'
            }`}>
              {PERSONAL_INFO.introduction}
            </p>

            {/* Resume & Call To Action Buttons */}
            <div className="flex flex-wrap gap-4 pt-4">
              <a
                href="#resume"
                id="hero-resume-view-btn"
                className="inline-flex items-center justify-center px-6 py-3 rounded-2xl font-medium text-white bg-gradient-to-r from-blue-500 via-purple-600 to-pink-600 shadow-lg shadow-blue-500/25 transition-all duration-300 hover:shadow-xl hover:shadow-purple-500/35 hover:-translate-y-1 active:scale-95 group"
              >
                <Download className="w-5 h-5 mr-2 group-hover:animate-bounce" />
                Download Resume
              </a>

              <a
                href="#contact"
                id="hero-contact-btn"
                className={`inline-flex items-center justify-center px-6 py-3 rounded-2xl font-medium transition-all duration-300 border hover:-translate-y-1 active:scale-95 ${
                  darkMode
                    ? 'bg-white/5 border-white/10 hover:bg-white/10 text-white'
                    : 'bg-white border-slate-200 text-slate-800 hover:bg-slate-50 shadow-sm'
                }`}
              >
                Contact Me
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1" />
              </a>
            </div>

            {/* Social Links */}
            <div className="flex items-center space-x-6 pt-6">
              <span className={`text-xs font-mono tracking-widest uppercase ${
                darkMode ? 'text-slate-500' : 'text-slate-400'
              }`}>
                Connect with me:
              </span>
              <div className="flex space-x-4">
                <a
                  href={PERSONAL_INFO.socials.github}
                  target="_blank"
                  referrerPolicy="no-referrer"
                  id="hero-social-github"
                  className={`p-3 rounded-xl transition-all duration-300 border hover:scale-110 hover:-translate-y-1 ${
                    darkMode
                      ? 'bg-white/5 border-white/10 text-slate-300 hover:text-white hover:border-blue-500'
                      : 'bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900 hover:border-blue-500'
                  }`}
                  title="GitHub"
                >
                  <Github className="w-5 h-5" />
                </a>
                <a
                  href={PERSONAL_INFO.socials.linkedin}
                  target="_blank"
                  referrerPolicy="no-referrer"
                  id="hero-social-linkedin"
                  className={`p-3 rounded-xl transition-all duration-300 border hover:scale-110 hover:-translate-y-1 ${
                    darkMode
                      ? 'bg-white/5 border-white/10 text-slate-300 hover:text-white hover:border-purple-500'
                      : 'bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900 hover:border-purple-500'
                  }`}
                  title="LinkedIn"
                >
                  <Linkedin className="w-5 h-5" />
                </a>
                <a
                  href={PERSONAL_INFO.socials.email}
                  id="hero-social-email"
                  className={`p-3 rounded-xl transition-all duration-300 border hover:scale-110 hover:-translate-y-1 ${
                    darkMode
                      ? 'bg-white/5 border-white/10 text-slate-300 hover:text-white hover:border-pink-500'
                      : 'bg-slate-100 border-slate-200 text-slate-600 hover:text-slate-900 hover:border-pink-500'
                  }`}
                  title="Email"
                >
                  <Mail className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>

          {/* Right Floating Developer Dashboard Illustration */}
          <div className="lg:col-span-5 relative flex justify-center items-center">
            <div className="relative w-full max-w-[420px] h-[400px] flex justify-center items-center">
              
              {/* Outer Decorative Ring */}
              <div className="absolute w-[360px] h-[360px] rounded-full border-2 border-dashed border-blue-500/10 dark:border-blue-500/20 animate-spin-slow" />
              <div className="absolute w-[280px] h-[280px] rounded-full border border-purple-500/10 dark:border-purple-500/20 animate-spin-reverse-slow" />

              {/* Main Code Terminal Card (Glassmorphism) */}
              <div className={`absolute w-[340px] sm:w-[360px] rounded-2xl border p-5 shadow-2xl transition-all duration-500 z-20 ${
                darkMode
                  ? 'bg-slate-900/80 border-white/15 shadow-black/50'
                  : 'bg-white/90 border-slate-200 shadow-slate-200/50'
              }`}>
                <div className="flex items-center justify-between pb-3 border-b border-white/10 dark:border-slate-800 mb-3">
                  <div className="flex space-x-1.5">
                    <span className="w-3 h-3 rounded-full bg-red-500" />
                    <span className="w-3 h-3 rounded-full bg-yellow-500" />
                    <span className="w-3 h-3 rounded-full bg-green-500" />
                  </div>
                  <span className={`text-xs font-mono ${
                    darkMode ? 'text-slate-500' : 'text-slate-400'
                  }`}>
                    sabari_dev.tsx
                  </span>
                  <Laptop className="w-4 h-4 text-slate-400" />
                </div>
                
                <div className="font-mono text-xs text-left space-y-2 select-none">
                  <div>
                    <span className="text-pink-500">const</span>{' '}
                    <span className="text-blue-400">developer</span> = &#123;
                  </div>
                  <div className="pl-4">
                    <span className="text-slate-400">name:</span>{' '}
                    <span className="text-amber-400">"{PERSONAL_INFO.name}"</span>,
                  </div>
                  <div className="pl-4">
                    <span className="text-slate-400">college:</span>{' '}
                    <span className="text-amber-400">"AVS Engg"</span>,
                  </div>
                  <div className="pl-4">
                    <span className="text-slate-400">cgpa:</span>{' '}
                    <span className="text-purple-400">8.8</span>,
                  </div>
                  <div className="pl-4">
                    <span className="text-slate-400">passion:</span>{' '}
                    <span className="text-emerald-400">["React", "AI", "Cyber"]</span>
                  </div>
                  <div>&#125;;</div>
                  
                  <div className="pt-2 text-slate-400 border-t border-slate-800 mt-2">
                    <span className="text-green-500">const</span>{' '}
                    <span className="text-blue-400">skills</span> = () =&gt; &#123;
                    <div className="pl-4 text-emerald-400">
                      buildFutureSystem();
                    </div>
                    &#125;;
                  </div>
                </div>
              </div>

              {/* Floating Element 1: React / Frontend badge */}
              <div className="absolute -top-4 -left-6 z-30 animate-float">
                <div className={`flex items-center space-x-2 px-3 py-2 rounded-xl border shadow-lg ${
                  darkMode ? 'bg-slate-900/90 border-blue-500/30' : 'bg-white/95 border-blue-500/20'
                }`}>
                  <div className="w-8 h-8 rounded-lg bg-blue-500/10 flex items-center justify-center text-blue-500">
                    <Code2 className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <div className={`text-[10px] font-mono leading-none ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>Frontend</div>
                    <div className={`text-xs font-bold leading-tight ${darkMode ? 'text-white' : 'text-slate-800'}`}>React UI</div>
                  </div>
                </div>
              </div>

              {/* Floating Element 2: AI ML Indicator */}
              <div className="absolute bottom-4 -right-6 z-30 animate-float-delayed">
                <div className={`flex items-center space-x-2 px-3 py-2 rounded-xl border shadow-lg ${
                  darkMode ? 'bg-slate-900/90 border-purple-500/30' : 'bg-white/95 border-purple-500/20'
                }`}>
                  <div className="w-8 h-8 rounded-lg bg-purple-500/10 flex items-center justify-center text-purple-400">
                    <Cpu className="w-5 h-5" />
                  </div>
                  <div className="text-left">
                    <div className={`text-[10px] font-mono leading-none ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>Intelligence</div>
                    <div className={`text-xs font-bold leading-tight ${darkMode ? 'text-white' : 'text-slate-800'}`}>AI & ML</div>
                  </div>
                </div>
              </div>

              {/* Floating Element 3: Cybersecurity Shield */}
              <div className="absolute top-1/4 -right-10 z-30 animate-float-slow">
                <div className={`flex items-center space-x-2 px-3 py-2 rounded-xl border shadow-lg ${
                  darkMode ? 'bg-slate-900/90 border-emerald-500/30' : 'bg-white/95 border-emerald-500/20'
                }`}>
                  <div className="w-8 h-8 rounded-lg bg-emerald-500/10 flex items-center justify-center text-emerald-400">
                    <ShieldAlert className="w-5 h-5 animate-pulse" />
                  </div>
                  <div className="text-left">
                    <div className={`text-[10px] font-mono leading-none ${darkMode ? 'text-slate-500' : 'text-slate-400'}`}>Security</div>
                    <div className={`text-xs font-bold leading-tight ${darkMode ? 'text-white' : 'text-slate-800'}`}>Certified</div>
                  </div>
                </div>
              </div>

              {/* Bottom Support Laptop Icon Circle */}
              <div className="absolute -bottom-6 -left-4 z-10 w-12 h-12 rounded-full bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 animate-pulse-slow" />
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
