import { useState } from 'react';
import { PROJECTS } from '../data';
import { Github, ExternalLink, Code2, FolderGit2, Sparkles } from 'lucide-react';

interface ProjectsProps {
  darkMode: boolean;
}

export default function Projects({ darkMode }: ProjectsProps) {
  const [activeCategory, setActiveCategory] = useState<'All' | 'React' | 'Java' | 'AI' | 'Web'>('All');

  const categories: ('All' | 'React' | 'Java' | 'AI' | 'Web')[] = ['All', 'React', 'Java', 'AI', 'Web'];

  const filteredProjects = PROJECTS.filter((p) => {
    if (activeCategory === 'All') return true;
    return p.category === activeCategory;
  });

  return (
    <section id="projects" className="py-24 relative overflow-hidden">
      {/* Decorative glow orb */}
      <div className="absolute left-1/3 bottom-10 w-96 h-96 bg-blue-500/5 dark:bg-blue-500/10 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="text-blue-500 font-mono text-sm tracking-widest uppercase px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20">
            Portfolio
          </span>
          <h2 className={`text-3xl sm:text-4xl font-extrabold mt-4 tracking-tight ${
            darkMode ? 'text-white' : 'text-slate-900'
          }`}>
            Featured{' '}
            <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              Projects & Prototypes
            </span>
          </h2>
          <p className={`mt-4 max-w-2xl mx-auto text-sm sm:text-base ${
            darkMode ? 'text-slate-400' : 'text-slate-600'
          }`}>
            A curated showcase of applications spanning web systems, Java algorithms, intelligence engines, and cybersecurity handbooks.
          </p>
        </div>

        {/* Category Filter Tabs */}
        <div className="flex flex-wrap justify-center items-center gap-2 mb-12">
          {categories.map((cat) => {
            const isActive = activeCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-5 py-2.5 rounded-xl text-sm font-semibold transition-all duration-300 focus:outline-none ${
                  isActive
                    ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white shadow-lg shadow-blue-500/25 scale-105'
                    : darkMode
                    ? 'bg-white/5 hover:bg-white/10 text-slate-300 hover:text-white border border-white/5'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600 hover:text-slate-900 shadow-sm'
                }`}
              >
                {cat === 'All' ? 'All Projects' : cat}
              </button>
            );
          })}
        </div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProjects.map((proj) => (
            <div
              key={proj.id}
              className={`rounded-3xl border overflow-hidden flex flex-col h-full transition-all duration-300 hover:scale-[1.02] hover:shadow-2xl group ${
                darkMode
                  ? 'bg-slate-900/40 border-white/10 hover:border-blue-500/30 shadow-black/35'
                  : 'bg-white border-slate-200 hover:border-blue-500/20 shadow-slate-100/60'
              }`}
            >
              {/* Card Image / Thumbnail */}
              <div className="relative h-48 overflow-hidden bg-slate-950">
                <img
                  src={proj.thumbnailUrl}
                  alt={proj.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110 opacity-80"
                />
                
                {/* Visual Glass Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-slate-950/20 to-transparent opacity-90" />
                
                {/* Category Tag on Image */}
                <span className="absolute top-4 right-4 text-xs font-mono font-bold px-3 py-1 rounded-full bg-blue-500/80 text-white shadow-md backdrop-blur-sm">
                  {proj.category}
                </span>
              </div>

              {/* Card Content */}
              <div className="p-6 flex flex-col justify-between flex-grow text-left">
                <div>
                  <h3 className={`text-xl font-bold mb-2 tracking-tight ${darkMode ? 'text-white' : 'text-slate-800'}`}>
                    {proj.title}
                  </h3>
                  
                  <p className={`text-sm leading-relaxed mb-4 line-clamp-3 ${
                    darkMode ? 'text-slate-300' : 'text-slate-600'
                  }`}>
                    {proj.description}
                  </p>
                </div>

                {/* Tags and Action buttons */}
                <div>
                  {/* Tech stack tags */}
                  <div className="flex flex-wrap gap-1.5 mb-5">
                    {proj.technologies.map((tech) => (
                      <span
                        key={tech}
                        className={`text-[10px] font-mono px-2 py-0.5 rounded ${
                          darkMode ? 'bg-white/5 text-slate-300' : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {tech}
                      </span>
                    ))}
                  </div>

                  {/* Links */}
                  <div className="flex items-center space-x-3 pt-4 border-t border-slate-200/50 dark:border-white/5">
                    <a
                      href={proj.githubUrl}
                      target="_blank"
                      referrerPolicy="no-referrer"
                      className={`flex-1 inline-flex items-center justify-center px-4 py-2 rounded-xl text-xs font-medium transition-all duration-300 border ${
                        darkMode
                          ? 'bg-white/5 border-white/10 hover:bg-white/10 text-slate-200 hover:text-white'
                          : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      <Github className="w-4 h-4 mr-1.5" />
                      Codebase
                    </a>
                    <a
                      href={proj.demoUrl}
                      onClick={(e) => {
                        if (proj.demoUrl === '#') {
                          e.preventDefault();
                          alert(`Demo initialized! This is a mock representation of "${proj.title}" running in client sandbox mode.`);
                        }
                      }}
                      className="flex-1 inline-flex items-center justify-center px-4 py-2 rounded-xl text-xs font-medium text-white bg-gradient-to-r from-blue-500 to-purple-600 hover:shadow-lg hover:shadow-blue-500/20"
                    >
                      <ExternalLink className="w-4 h-4 mr-1.5" />
                      Live Demo
                    </a>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

      </div>
    </section>
  );
}
