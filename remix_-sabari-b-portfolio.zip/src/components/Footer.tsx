import { Github, Linkedin, Mail, ShieldCheck, Heart } from 'lucide-react';
import { PERSONAL_INFO } from '../data';

interface FooterProps {
  darkMode: boolean;
}

export default function Footer({ darkMode }: FooterProps) {
  const links = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Skills', href: '#skills' },
    { name: 'Journey', href: '#journey' },
    { name: 'Services', href: '#services' },
    { name: 'Projects', href: '#projects' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <footer
      id="main-footer"
      className={`border-t py-12 transition-all duration-300 ${
        darkMode ? 'bg-[#030611]/90 border-white/10 text-slate-400' : 'bg-slate-50 border-slate-200 text-slate-600'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center text-center md:text-left">
          
          {/* Column 1: Logo & Tagline */}
          <div className="flex flex-col items-center md:items-start space-y-3">
            <a href="#home" className="flex items-center space-x-2 focus:outline-none">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-blue-500 to-purple-600 p-[2px]">
                <div className={`w-full h-full rounded-[10px] flex items-center justify-center font-black text-sm ${
                  darkMode ? 'bg-[#050816] text-white' : 'bg-white text-slate-900'
                }`}>
                  SB
                </div>
              </div>
              <span className={`font-bold tracking-wider text-lg ${darkMode ? 'text-white' : 'text-slate-800'}`}>
                Sabari B
              </span>
            </a>
            <p className="text-xs leading-relaxed max-w-xs text-slate-500">
              Third-Year Computer Science and Engineering student focused on premium Full Stack architectures, artificial networks, and cyber defense solutions.
            </p>
          </div>

          {/* Column 2: Navigation Links */}
          <div className="flex flex-wrap justify-center gap-x-6 gap-y-2">
            {links.map((link) => (
              <a
                key={link.name}
                href={link.href}
                className={`text-xs sm:text-sm font-medium transition-colors ${
                  darkMode ? 'hover:text-blue-400 text-slate-400' : 'hover:text-blue-600 text-slate-600'
                }`}
              >
                {link.name}
              </a>
            ))}
          </div>

          {/* Column 3: Social & Security indicators */}
          <div className="flex flex-col items-center md:items-end space-y-4">
            <div className="flex space-x-4">
              <a
                href={PERSONAL_INFO.socials.github}
                target="_blank"
                referrerPolicy="no-referrer"
                className={`p-2.5 rounded-xl transition-all border ${
                  darkMode
                    ? 'bg-white/5 border-white/5 text-slate-400 hover:text-white hover:border-white/10'
                    : 'bg-white border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
                title="GitHub"
              >
                <Github className="w-4 h-4" />
              </a>
              <a
                href={PERSONAL_INFO.socials.linkedin}
                target="_blank"
                referrerPolicy="no-referrer"
                className={`p-2.5 rounded-xl transition-all border ${
                  darkMode
                    ? 'bg-white/5 border-white/5 text-slate-400 hover:text-white hover:border-white/10'
                    : 'bg-white border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
                title="LinkedIn"
              >
                <Linkedin className="w-4 h-4" />
              </a>
              <a
                href={PERSONAL_INFO.socials.email}
                className={`p-2.5 rounded-xl transition-all border ${
                  darkMode
                    ? 'bg-white/5 border-white/5 text-slate-400 hover:text-white hover:border-white/10'
                    : 'bg-white border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                }`}
                title="Email"
              >
                <Mail className="w-4 h-4" />
              </a>
            </div>

            <span className="text-[10px] font-mono text-slate-500 flex items-center gap-1">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-500 animate-pulse" />
              Verified placement-ready profile
            </span>
          </div>

        </div>

        {/* Bottom copyright & attribution bar */}
        <div className="mt-8 pt-8 border-t border-slate-200/50 dark:border-white/5 flex flex-col sm:flex-row items-center justify-between text-[11px] font-mono text-slate-500">
          <div>
            © 2026 Sabari B. All Rights Reserved.
          </div>
          <div className="flex items-center gap-1 mt-2 sm:mt-0">
            Crafted with <Heart className="w-3 h-3 text-red-500 fill-red-500" /> & premium Tailwind styles
          </div>
        </div>

      </div>
    </footer>
  );
}
