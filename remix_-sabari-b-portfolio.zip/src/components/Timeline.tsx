import { EDUCATION, EXPERIENCE } from '../data';
import { GraduationCap, Briefcase, Calendar, Award, Star, Compass } from 'lucide-react';

interface TimelineProps {
  darkMode: boolean;
}

export default function Timeline({ darkMode }: TimelineProps) {
  return (
    <section id="journey" className="py-24 relative overflow-hidden">
      {/* Background Decor */}
      <div className="absolute left-10 bottom-10 w-90 h-90 bg-emerald-500/5 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-emerald-500 font-mono text-sm tracking-widest uppercase px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20">
            My Journey
          </span>
          <h2 className={`text-3xl sm:text-4xl font-extrabold mt-4 tracking-tight ${
            darkMode ? 'text-white' : 'text-slate-900'
          }`}>
            Education &{' '}
            <span className="bg-gradient-to-r from-emerald-400 to-teal-500 bg-clip-text text-transparent">
              Experience
            </span>
          </h2>
          <p className={`mt-4 max-w-2xl mx-auto text-sm sm:text-base ${
            darkMode ? 'text-slate-400' : 'text-slate-600'
          }`}>
            A timeline of my academic milestones alongside practical freelance exposure and personal learning sprints.
          </p>
        </div>

        {/* Timeline Columns */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-stretch">
          
          {/* Column 1: Education */}
          <div className="space-y-8 text-left">
            <div className="flex items-center space-x-3 mb-6">
              <div className="p-3 rounded-2xl bg-blue-500/10 text-blue-400 border border-blue-500/20">
                <GraduationCap className="w-6 h-6" />
              </div>
              <div>
                <h3 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-slate-800'}`}>
                  Academic Timeline
                </h3>
                <p className="text-xs text-slate-400 font-mono">Current and past studies</p>
              </div>
            </div>

            <div className="relative border-l-2 border-slate-200 dark:border-slate-800 ml-4 pl-8 space-y-12">
              {EDUCATION.map((item, index) => (
                <div key={item.id} className="relative group">
                  {/* Timeline bullet dot */}
                  <div className="absolute -left-[41px] top-1.5 w-6 h-6 rounded-full bg-[#050816] border-2 border-blue-500 flex items-center justify-center transition-transform group-hover:scale-110">
                    <span className="w-2.5 h-2.5 rounded-full bg-blue-500" />
                  </div>

                  {/* Glass Card content */}
                  <div className={`rounded-2xl p-6 border transition-all duration-300 hover:shadow-lg ${
                    darkMode
                      ? 'bg-slate-900/50 border-white/10 hover:border-blue-500/20'
                      : 'bg-white border-slate-200 hover:border-blue-500/20 shadow-sm'
                  }`}>
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                      <span className="inline-flex items-center text-xs font-mono font-bold px-2.5 py-1 rounded bg-blue-500/10 text-blue-400 border border-blue-500/20">
                        <Calendar className="w-3.5 h-3.5 mr-1" />
                        {item.durationOrStatus}
                      </span>
                      {item.extraInfo && (
                        <span className="inline-flex items-center text-xs font-mono font-extrabold px-2.5 py-1 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
                          <Star className="w-3.5 h-3.5 mr-1" />
                          {item.extraInfo}
                        </span>
                      )}
                    </div>

                    <h4 className={`text-lg font-bold leading-tight ${darkMode ? 'text-white' : 'text-slate-900'}`}>
                      {item.title}
                    </h4>
                    <p className="text-sm font-medium text-blue-500/90 dark:text-blue-400 mt-1">
                      {item.subtitle}
                    </p>
                    <p className={`text-xs font-semibold mt-0.5 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                      {item.institutionOrCompany}
                    </p>
                    <p className={`text-sm mt-3.5 leading-relaxed ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                      {item.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Column 2: Experience / Learning */}
          <div className="space-y-8 text-left">
            <div className="flex items-center space-x-3 mb-6">
              <div className="p-3 rounded-2xl bg-purple-500/10 text-purple-400 border border-purple-500/20">
                <Briefcase className="w-6 h-6" />
              </div>
              <div>
                <h3 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-slate-800'}`}>
                  Experience & Focus
                </h3>
                <p className="text-xs text-slate-400 font-mono">Real-world applications</p>
              </div>
            </div>

            <div className="relative border-l-2 border-slate-200 dark:border-slate-800 ml-4 pl-8 space-y-12">
              {EXPERIENCE.map((item, index) => (
                <div key={item.id} className="relative group">
                  {/* Timeline bullet dot */}
                  <div className="absolute -left-[41px] top-1.5 w-6 h-6 rounded-full bg-[#050816] border-2 border-purple-500 flex items-center justify-center transition-transform group-hover:scale-110">
                    <span className="w-2.5 h-2.5 rounded-full bg-purple-500" />
                  </div>

                  {/* Glass Card content */}
                  <div className={`rounded-2xl p-6 border transition-all duration-300 hover:shadow-lg ${
                    darkMode
                      ? 'bg-slate-900/50 border-white/10 hover:border-purple-500/20'
                      : 'bg-white border-slate-200 hover:border-purple-500/20 shadow-sm'
                  }`}>
                    <div className="flex flex-wrap items-center justify-between gap-2 mb-3">
                      <span className="inline-flex items-center text-xs font-mono font-bold px-2.5 py-1 rounded bg-purple-500/10 text-purple-400 border border-purple-500/20">
                        <Calendar className="w-3.5 h-3.5 mr-1" />
                        {item.durationOrStatus}
                      </span>
                      {item.extraInfo && (
                        <span className="inline-flex items-center text-xs font-mono font-bold px-2.5 py-1 rounded bg-slate-100 dark:bg-white/5 text-slate-600 dark:text-slate-300 border border-slate-200 dark:border-white/10">
                          {item.extraInfo}
                        </span>
                      )}
                    </div>

                    <h4 className={`text-lg font-bold leading-tight ${darkMode ? 'text-white' : 'text-slate-900'}`}>
                      {item.title}
                    </h4>
                    <p className="text-sm font-medium text-purple-500 dark:text-purple-400 mt-1">
                      {item.subtitle}
                    </p>
                    <p className={`text-xs font-semibold mt-0.5 ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>
                      {item.institutionOrCompany}
                    </p>
                    <p className={`text-sm mt-3.5 leading-relaxed ${darkMode ? 'text-slate-300' : 'text-slate-600'}`}>
                      {item.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
