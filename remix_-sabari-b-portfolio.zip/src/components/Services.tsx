import { SERVICES } from '../data';
import { Layers, Layout, Cpu, PenTool, Smartphone, Briefcase, LucideIcon } from 'lucide-react';

interface ServicesProps {
  darkMode: boolean;
}

export default function Services({ darkMode }: ServicesProps) {
  // Map string names to Lucide icons
  const iconMap: Record<string, LucideIcon> = {
    Layers: Layers,
    Layout: Layout,
    Cpu: Cpu,
    Figma: PenTool, // PenTool represents UI/UX nicely
    Smartphone: Smartphone,
    Briefcase: Briefcase,
  };

  return (
    <section id="services" className="py-24 relative overflow-hidden">
      {/* Background Decorative Gradient */}
      <div className="absolute top-1/2 left-0 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Title */}
        <div className="text-center mb-16">
          <span className="text-blue-500 font-mono text-sm tracking-widest uppercase px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20">
            Offerings
          </span>
          <h2 className={`text-3xl sm:text-4xl font-extrabold mt-4 tracking-tight ${
            darkMode ? 'text-white' : 'text-slate-900'
          }`}>
            Professional{' '}
            <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              Services & Solved Use-cases
            </span>
          </h2>
          <p className={`mt-4 max-w-2xl mx-auto text-sm sm:text-base ${
            darkMode ? 'text-slate-400' : 'text-slate-600'
          }`}>
            Highly customized, responsive, and secure solutions crafted to solve development goals and user layout problems.
          </p>
        </div>

        {/* Services Grid (6 glass cards) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {SERVICES.map((srv, i) => {
            const IconComponent = iconMap[srv.iconName] || Layers;
            
            // Assign custom gradients for visual rhythm
            const gradients = [
              'from-blue-500/20 to-purple-500/10 hover:border-blue-500/30',
              'from-cyan-500/20 to-blue-500/10 hover:border-cyan-500/30',
              'from-purple-500/20 to-pink-500/10 hover:border-purple-500/30',
              'from-emerald-500/20 to-teal-500/10 hover:border-emerald-500/30',
              'from-pink-500/20 to-rose-500/10 hover:border-pink-500/30',
              'from-amber-500/20 to-yellow-500/10 hover:border-amber-500/30',
            ];

            const colors = [
              'text-blue-500 dark:text-blue-400',
              'text-cyan-500 dark:text-cyan-400',
              'text-purple-500 dark:text-purple-400',
              'text-emerald-500 dark:text-emerald-400',
              'text-pink-500 dark:text-pink-400',
              'text-amber-500 dark:text-amber-400',
            ];

            return (
              <div
                key={srv.id}
                className={`rounded-2xl p-6 border text-left flex flex-col justify-between transition-all duration-300 hover:scale-[1.03] hover:shadow-xl group relative overflow-hidden ${
                  darkMode
                    ? 'bg-slate-900/40 border-white/10 shadow-black/30'
                    : 'bg-white border-slate-200 shadow-slate-100/50'
                } ${gradients[i % gradients.length]}`}
              >
                {/* Visual Glass Glow Background Pattern */}
                <div className="absolute top-0 right-0 w-24 h-24 bg-white/5 rounded-full blur-xl group-hover:scale-150 transition-transform duration-500" />

                <div>
                  {/* Service Icon inside a gradient box */}
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center mb-6 transition-transform duration-300 group-hover:rotate-6 ${
                    darkMode ? 'bg-white/5' : 'bg-slate-100'
                  }`}>
                    <IconComponent className={`w-7 h-7 ${colors[i % colors.length]}`} />
                  </div>

                  <h3 className={`text-lg font-bold mb-3 ${darkMode ? 'text-white' : 'text-slate-800'}`}>
                    {srv.title}
                  </h3>
                  
                  <p className={`text-sm leading-relaxed ${
                    darkMode ? 'text-slate-300' : 'text-slate-600'
                  }`}>
                    {srv.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-200/50 dark:border-white/5 flex items-center text-xs font-mono font-semibold text-slate-400 group-hover:text-blue-400 transition-colors">
                  <span>Learn more</span>
                  <span className="ml-1 transition-transform group-hover:translate-x-1">→</span>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
