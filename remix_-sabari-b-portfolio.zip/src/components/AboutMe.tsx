import { GraduationCap, Landmark, MapPin, BarChart3, Trophy, Compass, Heart } from 'lucide-react';
import { motion } from 'motion/react';

interface AboutMeProps {
  darkMode: boolean;
}

export default function AboutMe({ darkMode }: AboutMeProps) {
  const quickCards = [
    {
      icon: <GraduationCap className="w-6 h-6 text-blue-400" />,
      label: 'Degree',
      value: 'B.E Computer Science & Engineering',
      gradient: 'from-blue-500/10 to-cyan-500/10'
    },
    {
      icon: <Landmark className="w-6 h-6 text-purple-400" />,
      label: 'College',
      value: 'AVS Engineering College',
      gradient: 'from-purple-500/10 to-pink-500/10'
    },
    {
      icon: <MapPin className="w-6 h-6 text-emerald-400" />,
      label: 'Location',
      value: 'Salem, Tamil Nadu, India',
      gradient: 'from-emerald-500/10 to-teal-500/10'
    },
    {
      icon: <BarChart3 className="w-6 h-6 text-pink-400" />,
      label: 'CGPA',
      value: '8.8 / 10 (Consistently High)',
      gradient: 'from-pink-500/10 to-red-500/10'
    }
  ];

  return (
    <section id="about" className="py-24 relative overflow-hidden">
      {/* Decorative Blur BG */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full bg-blue-500/5 dark:bg-blue-500/10 blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Title */}
        <div className="text-center mb-16">
          <span className="text-blue-500 font-mono text-sm tracking-widest uppercase px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20">
            About Me
          </span>
          <h2 className={`text-3xl sm:text-4xl font-extrabold mt-4 tracking-tight ${
            darkMode ? 'text-white' : 'text-slate-900'
          }`}>
            My Personal{' '}
            <span className="bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">
              Story & Profile
            </span>
          </h2>
          <p className={`mt-4 max-w-2xl mx-auto text-sm sm:text-base ${
            darkMode ? 'text-slate-400' : 'text-slate-600'
          }`}>
            An insight into my academic background, technical passions, and the core drives behind my development journey.
          </p>
        </div>

        {/* Layout Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          
          {/* Left Side: Elegant Glassmorphism Main Story Card */}
          <div className="lg:col-span-7 space-y-6">
            <div className={`rounded-3xl p-6 sm:p-8 border shadow-xl transition-all ${
              darkMode
                ? 'bg-slate-900/40 border-white/10 text-slate-300'
                : 'bg-white/80 border-slate-200 text-slate-700 shadow-slate-100/50'
            }`}>
              <h3 className={`text-xl sm:text-2xl font-bold mb-4 flex items-center gap-2 ${
                darkMode ? 'text-white' : 'text-slate-900'
              }`}>
                <Compass className="w-6 h-6 text-blue-500" />
                Hello! I'm Sabari B
              </h3>
              
              <div className="space-y-4 leading-relaxed text-sm sm:text-base">
                <p>
                  I am a highly motivated third-year{' '}
                  <span className="font-semibold text-blue-400 dark:text-blue-400">
                    B.E. Computer Science and Engineering
                  </span>{' '}
                  student at{' '}
                  <span className="font-semibold text-purple-400 dark:text-purple-400">
                    AVS Engineering College
                  </span>{' '}
                  with a stellar current CGPA of{' '}
                  <strong className="text-emerald-500 font-mono text-lg bg-emerald-500/10 px-2 py-0.5 rounded">
                    8.8
                  </strong>
                  .
                </p>

                <p>
                  I am deeply passionate about Full Stack Development, Artificial Intelligence & Machine Learning, and Cybersecurity. I enjoy building modern web applications, solving complex real-world challenges, and continuously learning emerging technologies.
                </p>

                <p>
                  I believe that modern technology is a powerful tool to design cleaner, safer digital ecosystems. My projects blend rigorous backend stability, security compliance, and premium animated client-side layouts to give end users memorable interactive experiences.
                </p>
              </div>

              {/* Minimal Interests Tags */}
              <div className="mt-8 pt-6 border-t border-slate-200 dark:border-white/10 flex flex-wrap gap-2.5 items-center">
                <span className={`text-xs font-mono font-medium flex items-center gap-1.5 ${
                  darkMode ? 'text-slate-500' : 'text-slate-400'
                }`}>
                  <Heart className="w-3.5 h-3.5 text-pink-500 fill-pink-500" /> Interests:
                </span>
                {['Cyber Defense', 'Web Systems', 'Neural Networks', 'UI/UX Design', 'Continuous Learning'].map((tag) => (
                  <span
                    key={tag}
                    className={`text-xs px-3 py-1 rounded-full font-medium ${
                      darkMode
                        ? 'bg-white/5 border border-white/10 text-slate-300'
                        : 'bg-slate-100 border border-slate-200 text-slate-700'
                    }`}
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Right Side: Quick Info Bento Grid Cards */}
          <div className="lg:col-span-5 grid grid-cols-1 sm:grid-cols-2 gap-6 w-full">
            {quickCards.map((card, i) => (
              <div
                key={i}
                className={`rounded-2xl p-5 border flex flex-col justify-between transition-all duration-300 hover:scale-[1.03] hover:shadow-lg ${
                  darkMode
                    ? 'bg-slate-900/60 border-white/10 shadow-black/20 hover:border-blue-500/30'
                    : 'bg-white border-slate-200 shadow-slate-100 hover:border-blue-500/20'
                }`}
              >
                <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 bg-gradient-to-br ${card.gradient}`}>
                  {card.icon}
                </div>
                <div>
                  <span className={`text-xs font-mono tracking-wider uppercase ${
                    darkMode ? 'text-slate-500' : 'text-slate-400'
                  }`}>
                    {card.label}
                  </span>
                  <p className={`text-sm sm:text-base font-semibold mt-1 leading-tight ${
                    darkMode ? 'text-white' : 'text-slate-800'
                  }`}>
                    {card.value}
                  </p>
                </div>
              </div>
            ))}

            {/* Extra Interactive Card: Current Focus */}
            <div className={`sm:col-span-2 rounded-2xl p-5 border flex items-center justify-between transition-all duration-300 hover:shadow-lg ${
              darkMode
                ? 'bg-gradient-to-r from-blue-500/10 via-purple-500/10 to-pink-500/10 border-white/10'
                : 'bg-gradient-to-r from-blue-50/50 via-purple-50/50 to-pink-50/50 border-slate-200 shadow-sm'
            }`}>
              <div className="flex items-center space-x-3.5">
                <div className="relative">
                  <span className="absolute top-0 right-0 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-[#050816] animate-ping" />
                  <span className="absolute top-0 right-0 w-3.5 h-3.5 bg-emerald-500 rounded-full border-2 border-[#050816]" />
                  <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-500">
                    <Trophy className="w-5 h-5" />
                  </div>
                </div>
                <div className="text-left">
                  <div className={`text-xs font-mono ${darkMode ? 'text-slate-400' : 'text-slate-500'}`}>Current Status</div>
                  <div className={`text-sm font-bold ${darkMode ? 'text-white' : 'text-slate-800'}`}>Engineering 3rd Year (Active Placement Ready)</div>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
