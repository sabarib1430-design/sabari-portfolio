import { useState } from 'react';
import { SKILLS } from '../data';
import { Terminal, LayoutGrid, Database, Wrench, Sparkles, Code } from 'lucide-react';

interface SkillsProps {
  darkMode: boolean;
}

export default function Skills({ darkMode }: SkillsProps) {
  const [hoveredSkill, setHoveredSkill] = useState<string | null>(null);

  // Group skills by category
  const categories = [
    {
      name: 'Programming',
      icon: <Terminal className="w-5 h-5 text-blue-400" />,
      color: 'from-blue-500 to-indigo-500',
      badgeBg: 'bg-blue-500/10 text-blue-400',
      skills: SKILLS.filter((s) => s.category === 'Programming')
    },
    {
      name: 'Frontend',
      icon: <LayoutGrid className="w-5 h-5 text-purple-400" />,
      color: 'from-purple-500 to-pink-500',
      badgeBg: 'bg-purple-500/10 text-purple-400',
      skills: SKILLS.filter((s) => s.category === 'Frontend')
    },
    {
      name: 'Database',
      icon: <Database className="w-5 h-5 text-emerald-400" />,
      color: 'from-emerald-500 to-teal-500',
      badgeBg: 'bg-emerald-500/10 text-emerald-400',
      skills: SKILLS.filter((s) => s.category === 'Database')
    },
    {
      name: 'Tools',
      icon: <Wrench className="w-5 h-5 text-amber-400" />,
      color: 'from-amber-500 to-orange-500',
      badgeBg: 'bg-amber-500/10 text-amber-400',
      skills: SKILLS.filter((s) => s.category === 'Tools')
    }
  ];

  return (
    <section id="skills" className="py-24 relative overflow-hidden">
      {/* Background Glowing Orb */}
      <div className="absolute right-0 top-1/4 w-96 h-96 bg-purple-500/5 dark:bg-purple-500/10 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-purple-500 font-mono text-sm tracking-widest uppercase px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20">
            Expertise
          </span>
          <h2 className={`text-3xl sm:text-4xl font-extrabold mt-4 tracking-tight ${
            darkMode ? 'text-white' : 'text-slate-900'
          }`}>
            Technical{' '}
            <span className="bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
              Skills & Proficiencies
            </span>
          </h2>
          <p className={`mt-4 max-w-2xl mx-auto text-sm sm:text-base ${
            darkMode ? 'text-slate-400' : 'text-slate-600'
          }`}>
            My operational expertise across languages, user interface designs, databases, and version control tools.
          </p>
        </div>

        {/* Tech Stacks Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
          {categories.map((cat, catIdx) => (
            <div
              key={catIdx}
              className={`rounded-3xl p-6 sm:p-8 border transition-all duration-300 hover:shadow-xl ${
                darkMode
                  ? 'bg-slate-900/40 border-white/10 hover:border-purple-500/30'
                  : 'bg-white border-slate-200 hover:border-purple-500/20 shadow-slate-100/50'
              }`}
            >
              {/* Category Title */}
              <div className="flex items-center justify-between mb-8">
                <div className="flex items-center space-x-3">
                  <div className={`p-2.5 rounded-xl ${cat.badgeBg} border border-current/10`}>
                    {cat.icon}
                  </div>
                  <h3 className={`text-xl font-bold ${darkMode ? 'text-white' : 'text-slate-800'}`}>
                    {cat.name}
                  </h3>
                </div>
                <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
                  <Sparkles className="w-3 h-3 text-purple-400 animate-pulse" />
                  Standard Verified
                </span>
              </div>

              {/* Skills List with animatable bars */}
              <div className="space-y-6">
                {cat.skills.map((skill, sIdx) => {
                  const isHovered = hoveredSkill === skill.name;
                  return (
                    <div
                      key={sIdx}
                      className="group/item text-left"
                      onMouseEnter={() => setHoveredSkill(skill.name)}
                      onMouseLeave={() => setHoveredSkill(null)}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <span className={`text-sm font-semibold flex items-center gap-2 transition-colors ${
                          isHovered
                            ? 'text-blue-500 dark:text-blue-400'
                            : darkMode
                            ? 'text-slate-200'
                            : 'text-slate-700'
                        }`}>
                          <Code className="w-4 h-4 opacity-50" />
                          {skill.name}
                        </span>
                        <span className={`text-xs font-mono font-bold px-2 py-0.5 rounded ${
                          darkMode ? 'bg-white/5 text-slate-300' : 'bg-slate-100 text-slate-700'
                        }`}>
                          {skill.percentage}%
                        </span>
                      </div>

                      {/* Bar indicator */}
                      <div className={`h-2.5 w-full rounded-full overflow-hidden ${
                        darkMode ? 'bg-slate-800' : 'bg-slate-100'
                      }`}>
                        <div
                          className={`h-full rounded-full bg-gradient-to-r ${cat.color} transition-all duration-1000 ease-out`}
                          style={{
                            width: `${skill.percentage}%`,
                            boxShadow: isHovered
                              ? '0 0 12px rgba(168, 85, 247, 0.4)'
                              : 'none'
                          }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          ))}
        </div>

        {/* Dynamic technology floating banner block */}
        <div className={`mt-12 rounded-2xl p-5 border text-center relative overflow-hidden ${
          darkMode
            ? 'bg-slate-950/80 border-white/5'
            : 'bg-slate-50 border-slate-200'
        }`}>
          <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500" />
          <p className={`text-xs font-mono uppercase tracking-widest ${
            darkMode ? 'text-slate-500' : 'text-slate-400'
          }`}>
            Core Tools & Environments I use daily
          </p>
          <div className="flex flex-wrap items-center justify-center gap-6 mt-4">
            {['Vite', 'TypeScript', 'NodeJS', 'TailwindCSS', 'MongoDB', 'C / Java IDEs', 'Linux Console', 'Postman'].map((tool, i) => (
              <span
                key={i}
                className={`text-xs px-3.5 py-1.5 rounded-xl border font-semibold transition-all hover:scale-105 hover:-translate-y-0.5 ${
                  darkMode
                    ? 'bg-white/5 border-white/10 text-slate-300 hover:text-white hover:border-blue-500/30'
                    : 'bg-white border-slate-200 text-slate-700 hover:text-slate-900 shadow-sm'
                }`}
              >
                {tool}
              </span>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}
