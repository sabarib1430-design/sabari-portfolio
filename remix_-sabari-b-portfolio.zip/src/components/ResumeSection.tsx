import { useState } from 'react';
import { Download, Eye, FileText, CheckCircle, X, ExternalLink, Printer, Landmark, Award } from 'lucide-react';

interface ResumeSectionProps {
  darkMode: boolean;
}

export default function ResumeSection({ darkMode }: ResumeSectionProps) {
  const [showViewer, setShowViewer] = useState(false);
  const [downloaded, setDownloaded] = useState(false);

  const handleDownload = () => {
    setDownloaded(true);
    // Simulate downloading PDF
    setTimeout(() => {
      const element = document.createElement('a');
      const file = new Blob([
        `SABARI B - RESUME PORTFOLIO\n\n` +
        `CONTACT:\n` +
        `- Email: sabarib1430@gmail.com\n` +
        `- Phone: +91 7845135069\n` +
        `- LinkedIn: linkedin.com/in/sabari-b-074795398\n` +
        `- GitHub: github.com/sabarib1430-design\n\n` +
        `EDUCATION:\n` +
        `- B.E. Computer Science & Engineering | AVS Engineering College | CGPA: 8.8 / 10\n\n` +
        `TECHNICAL EXPERTISE:\n` +
        `- Languages: C, Java, JavaScript, TypeScript\n` +
        `- Frontend: HTML, CSS, React, Tailwind CSS\n` +
        `- Database: MongoDB\n` +
        `- Tools: VS Code, Git, GitHub\n\n` +
        `PROJECTS:\n` +
        `- Personal Glassmorphic Portfolio Website\n` +
        `- Student Management System (Java & SQL)\n` +
        `- AI Chatbot Assistant (Gemini API)\n` +
        `- Weather App\n` +
        `- Task Management System\n` +
        `- Cybersecurity Awareness Website\n\n` +
        `CERTIFICATIONS:\n` +
        `- Python Certificate\n` +
        `- Cybersecurity Certificate (Cisco/Google)\n`
      ], { type: 'text/plain' });
      element.href = URL.createObjectURL(file);
      element.download = 'Sabari_B_Resume.txt';
      document.body.appendChild(element);
      element.click();
      document.body.removeChild(element);
      setDownloaded(false);
    }, 1200);
  };

  return (
    <section id="resume" className="py-24 relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl -z-10" />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 text-center">
        
        {/* Centered Resume Card */}
        <div className={`rounded-3xl p-8 sm:p-12 border relative overflow-hidden transition-all duration-300 ${
          darkMode
            ? 'bg-slate-900/50 border-white/10 shadow-black/40'
            : 'bg-white border-slate-200 shadow-xl'
        }`}>
          {/* Subtle Top Decorative Lines */}
          <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500" />
          
          <div className="max-w-2xl mx-auto flex flex-col items-center">
            {/* Folder / Icon badge */}
            <div className="w-16 h-16 rounded-2xl bg-blue-500/10 flex items-center justify-center text-blue-500 mb-6 animate-float">
              <FileText className="w-8 h-8" />
            </div>

            <span className="text-blue-500 font-mono text-xs tracking-widest uppercase mb-2">
              Curriculum Vitae
            </span>
            
            <h2 className={`text-3xl sm:text-4xl font-extrabold mb-4 tracking-tight ${
              darkMode ? 'text-white' : 'text-slate-900'
            }`}>
              Download My Resume
            </h2>
            
            <p className={`text-sm sm:text-base mb-8 max-w-lg leading-relaxed ${
              darkMode ? 'text-slate-400' : 'text-slate-600'
            }`}>
              Get a copy of my professional resume structured for recruitment cycles, internship filters, client proposals, and placements.
            </p>

            {/* Action buttons */}
            <div className="flex flex-col sm:flex-row items-center gap-4 w-full justify-center">
              <button
                id="resume-view-btn"
                onClick={() => setShowViewer(true)}
                className={`w-full sm:w-auto inline-flex items-center justify-center px-6 py-3.5 rounded-2xl font-bold transition-all duration-300 border focus:outline-none hover:-translate-y-0.5 active:scale-95 ${
                  darkMode
                    ? 'bg-white/5 border-white/10 hover:bg-white/10 text-white'
                    : 'bg-slate-50 border-slate-200 text-slate-800 hover:bg-slate-100 shadow-sm'
                }`}
              >
                <Eye className="w-5 h-5 mr-2 text-blue-500" />
                View Resume Live
              </button>

              <button
                id="resume-download-btn"
                onClick={handleDownload}
                className="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3.5 rounded-2xl font-bold text-white bg-gradient-to-r from-blue-500 to-purple-600 shadow-lg shadow-blue-500/20 hover:shadow-xl hover:shadow-purple-500/30 transition-all duration-300 hover:-translate-y-0.5 active:scale-95 focus:outline-none"
              >
                {downloaded ? (
                  <>
                    <CheckCircle className="w-5 h-5 mr-2 text-emerald-400 animate-pulse" />
                    Downloading...
                  </>
                ) : (
                  <>
                    <Download className="w-5 h-5 mr-2" />
                    Download Resume
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

      </div>

      {/* Immersive Resume Fullscreen Overlay/Modal */}
      {showViewer && (
        <div className="fixed inset-0 z-50 overflow-y-auto flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
          <div className={`w-full max-w-4xl rounded-3xl border shadow-2xl relative overflow-hidden flex flex-col max-h-[90vh] ${
            darkMode ? 'bg-slate-950 border-white/15' : 'bg-slate-50 border-slate-200'
          }`}>
            
            {/* Header controls */}
            <div className={`px-6 py-4 border-b flex items-center justify-between sticky top-0 z-20 ${
              darkMode ? 'bg-slate-950/90 border-white/10' : 'bg-white/90 border-slate-200'
            }`}>
              <div className="flex items-center space-x-2">
                <FileText className="w-5 h-5 text-blue-500" />
                <span className={`font-bold text-sm sm:text-base ${darkMode ? 'text-white' : 'text-slate-800'}`}>
                  Sabari_B_Resume.pdf
                </span>
              </div>
              
              <div className="flex items-center space-x-3">
                <button
                  onClick={handleDownload}
                  className="p-2 rounded-lg text-slate-400 hover:text-white dark:hover:bg-white/5 hover:bg-slate-100"
                  title="Download File"
                >
                  <Download className="w-5 h-5" />
                </button>
                <button
                  onClick={() => setShowViewer(false)}
                  className="p-2 rounded-lg text-slate-400 hover:text-red-500 dark:hover:bg-white/5 hover:bg-slate-100"
                  title="Close Viewer"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Resume Sheet Content (styled beautifully as an elegant paper template) */}
            <div className="flex-grow overflow-y-auto p-6 sm:p-10">
              <div className={`w-full max-w-3xl mx-auto p-6 sm:p-8 rounded-2xl border text-left shadow-md bg-white text-slate-800 border-slate-300`}>
                
                {/* Resume Header */}
                <div className="border-b-2 border-blue-600 pb-5 mb-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div>
                    <h1 className="text-3xl font-bold tracking-tight text-slate-900">SABARI B</h1>
                    <p className="text-sm font-semibold text-blue-600 mt-1 uppercase tracking-wide">
                      Computer Science Student | Full Stack Developer
                    </p>
                  </div>
                  <div className="text-xs text-slate-500 font-mono space-y-1">
                    <div>📧 sabarib1430@gmail.com</div>
                    <div>📞 +91 7845135069</div>
                    <div>📍 Salem, Tamil Nadu</div>
                    <div>🔗 linkedin.com/in/sabari-b-074795398</div>
                  </div>
                </div>

                {/* Professional Objective */}
                <div className="mb-6">
                  <h2 className="text-xs font-bold uppercase tracking-wider text-blue-600 border-b border-slate-200 pb-1 mb-2">
                    Professional Summary
                  </h2>
                  <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                    Passionate third-year Computer Science and Engineering student at AVS Engineering College with a CGPA of 8.8. Proficient in web systems engineering, database setups, cybersecurity network defense, and visual design patterns. Experienced in creating responsive React environments, scripting utilities, and designing modular data pipelines.
                  </p>
                </div>

                {/* Education */}
                <div className="mb-6">
                  <h2 className="text-xs font-bold uppercase tracking-wider text-blue-600 border-b border-slate-200 pb-1 mb-2">
                    Education History
                  </h2>
                  <div className="flex justify-between items-start mb-1">
                    <div className="text-xs sm:text-sm font-bold text-slate-800">
                      B.E. Computer Science and Engineering
                    </div>
                    <div className="text-xs font-mono text-slate-500">2023 - Present (3rd Year)</div>
                  </div>
                  <div className="text-xs font-medium text-slate-600 flex items-center gap-1">
                    <Landmark className="w-3.5 h-3.5" />
                    AVS Engineering College | CGPA: 8.8 / 10
                  </div>
                </div>

                {/* Skills */}
                <div className="mb-6">
                  <h2 className="text-xs font-bold uppercase tracking-wider text-blue-600 border-b border-slate-200 pb-1 mb-2">
                    Technical Skills
                  </h2>
                  <div className="grid grid-cols-2 gap-y-2 gap-x-4 text-xs sm:text-sm">
                    <div>
                      <strong className="text-slate-800 text-[11px] uppercase tracking-wider">Languages:</strong>
                      <span className="text-slate-600 ml-1">C, Java, JavaScript, TypeScript</span>
                    </div>
                    <div>
                      <strong className="text-slate-800 text-[11px] uppercase tracking-wider">Frontend:</strong>
                      <span className="text-slate-600 ml-1">HTML5, CSS3, React, Tailwind CSS</span>
                    </div>
                    <div>
                      <strong className="text-slate-800 text-[11px] uppercase tracking-wider">Database:</strong>
                      <span className="text-slate-600 ml-1">MongoDB, MySQL / SQL dialect</span>
                    </div>
                    <div>
                      <strong className="text-slate-800 text-[11px] uppercase tracking-wider">Version Tools:</strong>
                      <span className="text-slate-600 ml-1">VS Code, Git command line, GitHub</span>
                    </div>
                  </div>
                </div>

                {/* Projects */}
                <div className="mb-6">
                  <h2 className="text-xs font-bold uppercase tracking-wider text-blue-600 border-b border-slate-200 pb-1 mb-2">
                    Featured Engineering Projects
                  </h2>
                  <div className="space-y-3.5">
                    <div>
                      <div className="flex justify-between text-xs sm:text-sm font-bold text-slate-800">
                        <span>Personal Glassmorphic Portfolio Website</span>
                        <span className="text-[10px] text-blue-600 font-mono">React, Tailwind</span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed mt-1">
                        Designed a premium portfolio website incorporating responsive hamburger menus, color mode configurations, animated progress cells, and live simulated GitHub commits.
                      </p>
                    </div>
                    <div>
                      <div className="flex justify-between text-xs sm:text-sm font-bold text-slate-800">
                        <span>Student Management System</span>
                        <span className="text-[10px] text-blue-600 font-mono">Java, JDBC</span>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed mt-1">
                        Built a secure relational software portal managing admissions, classroom schedules, grades, and teacher logs.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Certifications */}
                <div>
                  <h2 className="text-xs font-bold uppercase tracking-wider text-blue-600 border-b border-slate-200 pb-1 mb-2">
                    Certifications & Badges
                  </h2>
                  <ul className="list-disc list-inside text-xs sm:text-sm text-slate-600 space-y-1.5">
                    <li>Python Certificate – GUVI & IBM Cognitive Class credentials</li>
                    <li>Cybersecurity Certificate – Network Security essentials, Cisco Networking Academy</li>
                  </ul>
                </div>

              </div>
            </div>

            {/* Footer view action */}
            <div className={`px-6 py-4 border-t flex justify-end gap-3 sticky bottom-0 ${
              darkMode ? 'bg-slate-950 border-white/10' : 'bg-white border-slate-200'
            }`}>
              <button
                onClick={() => setShowViewer(false)}
                className={`px-4 py-2 rounded-xl text-xs font-medium border ${
                  darkMode
                    ? 'border-white/10 text-slate-300 hover:bg-white/5'
                    : 'border-slate-200 text-slate-700 hover:bg-slate-100'
                }`}
              >
                Close View
              </button>
              <button
                onClick={handleDownload}
                className="px-4 py-2 rounded-xl text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 shadow-md"
              >
                Download PDF/Txt
              </button>
            </div>

          </div>
        </div>
      )}
    </section>
  );
}
