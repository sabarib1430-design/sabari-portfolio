import { useState, useEffect } from 'react';
import { Menu, X, Sun, Moon, Terminal } from 'lucide-react';

interface HeaderProps {
  darkMode: boolean;
  setDarkMode: (dark: boolean) => void;
  activeSection: string;
}

export default function Header({ darkMode, setDarkMode, activeSection }: HeaderProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { name: 'Home', href: '#home' },
    { name: 'About', href: '#about' },
    { name: 'Skills', href: '#skills' },
    { name: 'Journey', href: '#journey' },
    { name: 'Services', href: '#services' },
    { name: 'Projects', href: '#projects' },
    { name: 'Achievements', href: '#achievements' },
    { name: 'Stats', href: '#stats' },
    { name: 'Contact', href: '#contact' },
  ];

  return (
    <header
      id="main-header"
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled
          ? darkMode
            ? 'bg-[#050816]/80 border-b border-white/10 backdrop-blur-md py-3'
            : 'bg-white/80 border-b border-slate-200 backdrop-blur-md py-3 shadow-sm'
          : 'bg-transparent py-5'
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <a
            href="#home"
            id="nav-logo"
            className="flex items-center space-x-2 group focus:outline-none"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-blue-500 via-purple-500 to-pink-500 p-[2px] transition-transform duration-300 group-hover:scale-105">
              <div className={`w-full h-full rounded-[10px] flex items-center justify-center font-bold text-lg ${
                darkMode ? 'bg-[#050816] text-white' : 'bg-white text-slate-900'
              }`}>
                SB
              </div>
            </div>
            <span className={`font-bold tracking-wider text-xl flex items-center gap-1 ${
              darkMode ? 'text-white' : 'text-slate-900'
            }`}>
              Sabari
              <span className="text-blue-500">.</span>
              <Terminal className="w-4 h-4 text-purple-500 animate-pulse" />
            </span>
          </a>

          {/* Desktop Navigation */}
          <nav id="desktop-nav" className="hidden lg:flex items-center space-x-1">
            {navItems.map((item) => {
              const isActive = activeSection === item.href.slice(1);
              return (
                <a
                  key={item.name}
                  href={item.href}
                  className={`px-3 py-2 rounded-lg text-sm font-medium transition-all duration-300 relative group ${
                    isActive
                      ? darkMode
                        ? 'text-blue-400 font-semibold'
                        : 'text-blue-600 font-semibold'
                      : darkMode
                      ? 'text-slate-300 hover:text-white'
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {item.name}
                  {/* Underline Indicator */}
                  {isActive && (
                    <span className="absolute bottom-0 left-3 right-3 h-[2px] bg-gradient-to-r from-blue-500 to-purple-500 rounded-full" />
                  )}
                  {/* Hover effect indicator */}
                  {!isActive && (
                    <span className="absolute bottom-0 left-1/2 w-0 h-[2px] bg-blue-500/50 transition-all duration-300 group-hover:w-1/2 group-hover:left-1/4 rounded-full" />
                  )}
                </a>
              );
            })}
          </nav>

          {/* Action buttons (Dark Mode, Resume Shortcut, Hamburger Menu) */}
          <div className="flex items-center space-x-4">
            {/* Theme Toggle */}
            <button
              id="theme-toggle"
              onClick={() => setDarkMode(!darkMode)}
              className={`p-2 rounded-xl transition-all duration-300 border focus:outline-none hover:scale-105 ${
                darkMode
                  ? 'bg-white/5 border-white/10 text-yellow-400 hover:bg-white/10'
                  : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200 shadow-sm'
              }`}
              aria-label="Toggle dark/light theme"
            >
              {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </button>

            {/* Quick Resume Link */}
            <a
              href="#resume"
              id="header-resume-btn"
              className="hidden sm:inline-flex items-center justify-center px-4 py-2 rounded-xl text-sm font-medium transition-all duration-300 border glow-btn bg-gradient-to-r from-blue-500 to-purple-600 text-white border-transparent hover:shadow-lg hover:shadow-blue-500/20 active:scale-95"
            >
              Resume
            </a>

            {/* Mobile menu toggle button */}
            <button
              id="mobile-menu-toggle"
              onClick={() => setIsOpen(!isOpen)}
              className={`lg:hidden p-2 rounded-xl transition-all duration-300 border focus:outline-none ${
                darkMode
                  ? 'bg-white/5 border-white/10 text-white hover:bg-white/10'
                  : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200'
              }`}
              aria-label="Toggle menu"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer menu */}
      {isOpen && (
        <div
          id="mobile-menu"
          className={`lg:hidden absolute top-full left-0 w-full border-t transition-all duration-300 ${
            darkMode
              ? 'bg-[#050816]/95 border-white/10 backdrop-blur-lg shadow-2xl'
              : 'bg-white/95 border-slate-200 backdrop-blur-lg shadow-xl'
          }`}
        >
          <div className="px-4 pt-3 pb-6 space-y-2">
            {navItems.map((item) => {
              const isActive = activeSection === item.href.slice(1);
              return (
                <a
                  key={item.name}
                  href={item.href}
                  onClick={() => setIsOpen(false)}
                  className={`block px-4 py-3 rounded-xl text-base font-medium transition-all ${
                    isActive
                      ? darkMode
                        ? 'bg-blue-500/10 text-blue-400 border-l-4 border-blue-500'
                        : 'bg-blue-500/5 text-blue-600 border-l-4 border-blue-600 font-semibold'
                      : darkMode
                      ? 'text-slate-300 hover:bg-white/5 hover:text-white'
                      : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
                  }`}
                >
                  {item.name}
                </a>
              );
            })}
            <div className="pt-4 border-t border-slate-200 dark:border-white/10 px-4">
              <a
                href="#resume"
                onClick={() => setIsOpen(false)}
                className="w-full flex items-center justify-center px-4 py-3 rounded-xl text-base font-medium text-white bg-gradient-to-r from-blue-500 to-purple-600 text-center hover:opacity-95"
              >
                View Resume
              </a>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
