import { useState } from 'react';
import { GitBranch, Star, Activity, Flame, Award, Globe, Code2, Sparkles, AlertCircle } from 'lucide-react';

interface GitHubStatsProps {
  darkMode: boolean;
}

export default function GitHubStats({ darkMode }: GitHubStatsProps) {
  const [hoveredDay, setHoveredDay] = useState<{ count: number; date: string } | null>(null);

  // Simulated streak values
  const streakStats = [
    { label: 'Current Streak', value: '34 Days', icon: <Flame className="w-5 h-5 text-orange-500 animate-bounce" /> },
    { label: 'Longest Streak', value: '82 Days', icon: <Award className="w-5 h-5 text-yellow-500" /> },
    { label: 'Total Contributions', value: '1,430 Commits', icon: <Activity className="w-5 h-5 text-emerald-500" /> },
    { label: 'Repositories', value: '18 Active', icon: <GitBranch className="w-5 h-5 text-blue-500" /> }
  ];

  // Top languages stats
  const languages = [
    { name: 'Java', percentage: 45, color: 'bg-red-500', text: 'text-red-500' },
    { name: 'JavaScript / React', percentage: 35, color: 'bg-blue-500', text: 'text-blue-500' },
    { name: 'C Language', percentage: 15, color: 'bg-slate-400', text: 'text-slate-400' },
    { name: 'HTML & CSS', percentage: 5, color: 'bg-orange-500', text: 'text-orange-500' }
  ];

  // Simulated Repositories
  const activeRepos = [
    {
      name: 'student-management-system',
      desc: 'High-performance desktop system managing student files, marks, schedules, and attendance records.',
      lang: 'Java',
      langColor: 'bg-red-500',
      stars: 12,
      forks: 4
    },
    {
      name: 'portfolio-glassmorphism',
      desc: 'This fully responsive portfolio website featuring a clean cyberpunk glassmorphism structure.',
      lang: 'TypeScript',
      langColor: 'bg-blue-500',
      stars: 18,
      forks: 2
    },
    {
      name: 'cybersecurity-awareness',
      desc: 'A complete handbook portal guiding users about digital defense mechanism, phishing mitigation, and cryptography.',
      lang: 'JavaScript',
      langColor: 'bg-yellow-400',
      stars: 8,
      forks: 1
    }
  ];

  // Render a simulated contribution heatmap (e.g., 24 weeks * 7 days = 168 blocks)
  // Fill each with simulated commit values (0, 1-3, 4-7, 8+)
  const contributionHeatmap = Array.from({ length: 168 }, (_, i) => {
    // Make weekends lower, mid-weeks higher, and random variations
    const dayOfWeek = i % 7;
    const randomSeed = Math.sin(i) * 10;
    let count = 0;
    
    if (dayOfWeek !== 0 && dayOfWeek !== 6) {
      if (randomSeed > 7) count = Math.floor(Math.random() * 9) + 4; // High commits
      else if (randomSeed > 0) count = Math.floor(Math.random() * 4) + 1; // Medium commits
    } else {
      if (randomSeed > 8) count = Math.floor(Math.random() * 3) + 1; // Low commits on weekends
    }

    // Generate date string for tooltip
    const date = new Date();
    date.setDate(date.getDate() - (168 - i));
    const dateStr = date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });

    return { count, date: dateStr };
  });

  return (
    <section id="stats" className="py-24 relative overflow-hidden">
      {/* Decorative Blur Background */}
      <div className="absolute top-1/4 left-1/4 w-80 h-80 bg-blue-500/5 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-blue-500 font-mono text-sm tracking-widest uppercase px-3 py-1 rounded-full bg-blue-500/10 border border-blue-500/20">
            Analytics
          </span>
          <h2 className={`text-3xl sm:text-4xl font-extrabold mt-4 tracking-tight ${
            darkMode ? 'text-white' : 'text-slate-900'
          }`}>
            GitHub{' '}
            <span className="bg-gradient-to-r from-blue-400 via-purple-500 to-pink-500 bg-clip-text text-transparent">
              Statistics & Contributions
            </span>
          </h2>
          <p className={`mt-4 max-w-2xl mx-auto text-sm sm:text-base ${
            darkMode ? 'text-slate-400' : 'text-slate-600'
          }`}>
            An interactive dashboard visualizing active streaks, language ratios, and live-representation heatmap commits.
          </p>
        </div>

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          
          {/* Main Top Area: Streak stats & contribution graph (Lg: col 8) */}
          <div className="lg:col-span-8 flex flex-col justify-between space-y-8">
            
            {/* 1. Streaks Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {streakStats.map((stat, idx) => (
                <div
                  key={idx}
                  className={`rounded-2xl p-4 border text-left flex flex-col justify-between transition-all ${
                    darkMode
                      ? 'bg-slate-900/50 border-white/10 hover:border-blue-500/25'
                      : 'bg-white border-slate-200 shadow-sm hover:border-blue-500/20'
                  }`}
                >
                  <div className="flex items-center justify-between mb-3">
                    <span className={`text-[10px] font-mono tracking-wider uppercase ${
                      darkMode ? 'text-slate-500' : 'text-slate-400'
                    }`}>
                      {stat.label}
                    </span>
                    {stat.icon}
                  </div>
                  <span className={`text-xl font-bold font-mono ${
                    darkMode ? 'text-white' : 'text-slate-800'
                  }`}>
                    {stat.value}
                  </span>
                </div>
              ))}
            </div>

            {/* 2. Interactive Heatmap Card */}
            <div className={`rounded-3xl p-6 border text-left flex-grow ${
              darkMode ? 'bg-slate-900/40 border-white/10' : 'bg-white border-slate-200 shadow-sm'
            }`}>
              <div className="flex flex-wrap items-center justify-between gap-4 mb-6">
                <div className="flex items-center space-x-2">
                  <Globe className="w-5 h-5 text-emerald-400" />
                  <h3 className={`text-base font-bold ${darkMode ? 'text-white' : 'text-slate-800'}`}>
                    Active Contribution Heatmap
                  </h3>
                </div>
                <div className="flex items-center space-x-2 text-xs text-slate-400 font-mono">
                  <span>Less</span>
                  <span className="w-2.5 h-2.5 rounded-sm bg-slate-200 dark:bg-slate-800" />
                  <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500/30" />
                  <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500/60" />
                  <span className="w-2.5 h-2.5 rounded-sm bg-emerald-500" />
                  <span>More</span>
                </div>
              </div>

              {/* Grid representation */}
              <div className="relative">
                <div className="grid grid-flow-col grid-rows-7 gap-1.5 overflow-x-auto pb-4 scrollbar-thin">
                  {contributionHeatmap.map((day, i) => {
                    let color = 'bg-slate-200 dark:bg-slate-800'; // No commits
                    if (day.count > 0 && day.count <= 3) color = 'bg-emerald-500/30';
                    else if (day.count > 3 && day.count <= 7) color = 'bg-emerald-500/60';
                    else if (day.count > 7) color = 'bg-emerald-500';

                    return (
                      <div
                        key={i}
                        className={`w-3.5 h-3.5 rounded-sm cursor-crosshair transition-all hover:scale-125 ${color}`}
                        onMouseEnter={() => setHoveredDay(day)}
                        onMouseLeave={() => setHoveredDay(null)}
                      />
                    );
                  })}
                </div>

                {/* Live Tooltip display */}
                <div className="h-6 flex items-center justify-center font-mono text-xs text-slate-400 mt-2">
                  {hoveredDay ? (
                    <span className="bg-emerald-500/10 border border-emerald-500/20 px-3 py-1 rounded text-emerald-400 flex items-center gap-1.5 animate-pulse">
                      <Sparkles className="w-3 h-3" />
                      <strong>{hoveredDay.count} commits</strong> on {hoveredDay.date}
                    </span>
                  ) : (
                    <span>Hover over any cell to inspect commits timeline</span>
                  )}
                </div>
              </div>
            </div>

          </div>

          {/* Right Area: Language breakdown (Lg: col 4) */}
          <div className="lg:col-span-4">
            <div className={`rounded-3xl p-6 border text-left h-full flex flex-col justify-between ${
              darkMode ? 'bg-slate-900/40 border-white/10' : 'bg-white border-slate-200 shadow-sm'
            }`}>
              <div>
                <div className="flex items-center space-x-2 mb-6">
                  <Code2 className="w-5 h-5 text-blue-400" />
                  <h3 className={`text-base font-bold ${darkMode ? 'text-white' : 'text-slate-800'}`}>
                    Top Languages
                  </h3>
                </div>

                {/* Progress bar lists for Languages */}
                <div className="space-y-5">
                  {languages.map((lang, idx) => (
                    <div key={idx} className="space-y-2">
                      <div className="flex justify-between text-xs font-semibold">
                        <span className={`flex items-center gap-2 ${darkMode ? 'text-slate-300' : 'text-slate-700'}`}>
                          <span className={`w-2.5 h-2.5 rounded-full ${lang.color}`} />
                          {lang.name}
                        </span>
                        <span className="font-mono text-slate-400">{lang.percentage}%</span>
                      </div>
                      <div className={`h-2 w-full rounded-full ${
                        darkMode ? 'bg-slate-800' : 'bg-slate-100'
                      }`}>
                        <div
                          className={`h-full rounded-full ${lang.color}`}
                          style={{ width: `${lang.percentage}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Small Info box */}
              <div className={`mt-8 rounded-xl p-4 flex items-start gap-2.5 text-xs leading-relaxed ${
                darkMode ? 'bg-white/5 text-slate-400' : 'bg-slate-100 text-slate-600'
              }`}>
                <AlertCircle className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
                <span>
                  Language index statistics are automatically compiled weekly from active repositories on public workspace servers.
                </span>
              </div>
            </div>
          </div>

          {/* Bottom Area: Active Repository list (Lg: col 12) */}
          <div className="lg:col-span-12 space-y-6 text-left">
            <h3 className={`text-lg font-bold flex items-center gap-2 mt-4 ${
              darkMode ? 'text-white' : 'text-slate-800'
            }`}>
              <GitBranch className="w-5 h-5 text-purple-400" />
              Pinned Repositories
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {activeRepos.map((repo, idx) => (
                <div
                  key={idx}
                  className={`rounded-2xl p-5 border text-left flex flex-col justify-between transition-all duration-300 hover:scale-[1.02] hover:shadow-lg ${
                    darkMode
                      ? 'bg-[#050816] border-white/15 hover:border-purple-500/30'
                      : 'bg-white border-slate-200 hover:border-purple-500/20 shadow-sm'
                  }`}
                >
                  <div>
                    <div className="flex items-center justify-between mb-3">
                      <a
                        href={`https://github.com/sabarib1430-design/${repo.name}`}
                        target="_blank"
                        referrerPolicy="no-referrer"
                        className="text-sm font-bold text-blue-500 dark:text-blue-400 hover:underline font-mono"
                      >
                        {repo.name}
                      </a>
                      <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${
                        darkMode ? 'bg-white/5 border-white/10 text-slate-400' : 'bg-slate-100 border-slate-200 text-slate-600'
                      }`}>
                        Public
                      </span>
                    </div>
                    <p className={`text-xs leading-relaxed mb-4 line-clamp-3 ${
                      darkMode ? 'text-slate-400' : 'text-slate-600'
                    }`}>
                      {repo.desc}
                    </p>
                  </div>

                  <div className="flex items-center justify-between text-xs font-mono text-slate-400 pt-3 border-t border-slate-200/50 dark:border-white/5">
                    <span className="flex items-center gap-1.5">
                      <span className={`w-2.5 h-2.5 rounded-full ${repo.langColor}`} />
                      {repo.lang}
                    </span>
                    <div className="flex items-center space-x-3">
                      <span className="flex items-center gap-1">
                        <Star className="w-3.5 h-3.5 text-yellow-500" />
                        {repo.stars}
                      </span>
                      <span className="flex items-center gap-1">
                        <GitBranch className="w-3.5 h-3.5" />
                        {repo.forks}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
