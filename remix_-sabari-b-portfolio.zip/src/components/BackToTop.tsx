import { useEffect, useState } from 'react';
import { ArrowUp } from 'lucide-react';

export default function BackToTop() {
  const [isVisible, setIsVisible] = useState(false);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const toggleVisibilityAndProgress = () => {
      const scrolled = window.scrollY;
      const totalHeight = document.documentElement.scrollHeight - window.innerHeight;
      
      if (scrolled > 300) {
        setIsVisible(true);
      } else {
        setIsVisible(false);
      }

      if (totalHeight > 0) {
        setScrollProgress((scrolled / totalHeight) * 100);
      }
    };

    window.addEventListener('scroll', toggleVisibilityAndProgress);
    return () => window.removeEventListener('scroll', toggleVisibilityAndProgress);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth',
    });
  };

  if (!isVisible) return null;

  return (
    <button
      onClick={scrollToTop}
      className="fixed bottom-6 right-6 z-50 p-3 rounded-full bg-slate-900/90 hover:bg-gradient-to-r hover:from-blue-500 hover:to-purple-600 border border-white/10 text-white shadow-xl flex items-center justify-center transition-all duration-300 hover:scale-110 active:scale-90 group focus:outline-none"
      title="Scroll Back To Top"
    >
      {/* Scroll Progress Radial SVG */}
      <svg className="absolute w-12 h-12 -rotate-90 pointer-events-none">
        <circle
          cx="24"
          cy="24"
          r="21"
          stroke="rgba(255, 255, 255, 0.1)"
          strokeWidth="2"
          fill="transparent"
        />
        <circle
          cx="24"
          cy="24"
          r="21"
          stroke="url(#progress-gradient)"
          strokeWidth="3.5"
          fill="transparent"
          strokeDasharray="132"
          strokeDashoffset={132 - (132 * scrollProgress) / 100}
          className="transition-all duration-100"
        />
        <defs>
          <linearGradient id="progress-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#3B82F6" />
            <stop offset="100%" stopColor="#A855F7" />
          </linearGradient>
        </defs>
      </svg>

      <ArrowUp className="w-5 h-5 transition-transform group-hover:-translate-y-0.5" />
    </button>
  );
}
