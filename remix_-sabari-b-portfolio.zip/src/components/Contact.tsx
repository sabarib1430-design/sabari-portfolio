import { useState, FormEvent } from 'react';
import { Mail, Phone, MapPin, Linkedin, Github, Send, CheckCircle2, AlertCircle, RefreshCw } from 'lucide-react';
import { PERSONAL_INFO } from '../data';

interface ContactProps {
  darkMode: boolean;
}

export default function Contact({ darkMode }: ContactProps) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  
  // Validation / Feedback states
  const [errors, setErrors] = useState<{ name?: string; email?: string; message?: string }>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const validateForm = () => {
    const newErrors: { name?: string; email?: string; message?: string } = {};
    if (!name.trim()) newErrors.name = 'Please provide your full name.';
    if (!email.trim()) {
      newErrors.email = 'Please provide an email address.';
    } else if (!/\S+@\S+\.\S+/.test(email)) {
      newErrors.email = 'Please enter a valid email address.';
    }
    if (!message.trim()) newErrors.message = 'Please write a message so I can reply.';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!validateForm()) return;

    setIsSubmitting(true);
    
    // Simulate API pipeline submit
    setTimeout(() => {
      setIsSubmitting(false);
      setSubmitted(true);
      
      // Clear fields
      setName('');
      setEmail('');
      setSubject('');
      setMessage('');
    }, 1500);
  };

  return (
    <section id="contact" className="py-24 relative overflow-hidden">
      {/* Background radial highlight */}
      <div className="absolute right-0 bottom-0 w-[400px] h-[400px] bg-purple-500/5 rounded-full blur-3xl -z-10" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-purple-500 font-mono text-sm tracking-widest uppercase px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20">
            Get In Touch
          </span>
          <h2 className={`text-3xl sm:text-4xl font-extrabold mt-4 tracking-tight ${
            darkMode ? 'text-white' : 'text-slate-900'
          }`}>
            Contact{' '}
            <span className="bg-gradient-to-r from-purple-400 to-pink-500 bg-clip-text text-transparent">
              My Workspace
            </span>
          </h2>
          <p className={`mt-4 max-w-2xl mx-auto text-sm sm:text-base ${
            darkMode ? 'text-slate-400' : 'text-slate-600'
          }`}>
            Have an internship opening, freelance proposal, or a general engineering question? Send a message directly!
          </p>
        </div>

        {/* Split Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          
          {/* Left Side: Contact details info card (Lg: col 5) */}
          <div className="lg:col-span-5 flex flex-col justify-between space-y-8">
            <div className={`rounded-3xl p-6 sm:p-8 border h-full flex flex-col justify-between ${
              darkMode
                ? 'bg-slate-900/40 border-white/10 text-slate-300'
                : 'bg-white border-slate-200 text-slate-700 shadow-sm'
            }`}>
              
              <div className="space-y-8">
                <h3 className={`text-xl font-bold mb-4 ${darkMode ? 'text-white' : 'text-slate-800'}`}>
                  Direct Contacts
                </h3>

                {/* Email, Phone, Location blocks with nice icon boxes */}
                <div className="space-y-6">
                  
                  {/* Email */}
                  <a
                    href={PERSONAL_INFO.socials.email}
                    className="flex items-center space-x-4 p-3 rounded-xl transition-all hover:bg-white/5 border border-transparent hover:border-white/5 text-left group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center text-blue-500 shrink-0 group-hover:scale-110 transition-transform">
                      <Mail className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="text-[10px] font-mono tracking-wider uppercase text-slate-500 dark:text-slate-500">Email Address</span>
                      <p className={`text-sm sm:text-base font-semibold group-hover:text-blue-400 transition-colors ${
                        darkMode ? 'text-white' : 'text-slate-800'
                      }`}>
                        sabarib1430@gmail.com
                      </p>
                    </div>
                  </a>

                  {/* Phone */}
                  <a
                    href={PERSONAL_INFO.socials.phone}
                    className="flex items-center space-x-4 p-3 rounded-xl transition-all hover:bg-white/5 border border-transparent hover:border-white/5 text-left group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center text-purple-400 shrink-0 group-hover:scale-110 transition-transform">
                      <Phone className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="text-[10px] font-mono tracking-wider uppercase text-slate-500 dark:text-slate-500">Phone Number</span>
                      <p className={`text-sm sm:text-base font-semibold group-hover:text-purple-400 transition-colors ${
                        darkMode ? 'text-white' : 'text-slate-800'
                      }`}>
                        +91 7845135069
                      </p>
                    </div>
                  </a>

                  {/* Location */}
                  <div className="flex items-center space-x-4 p-3 rounded-xl text-left">
                    <div className="w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-400 shrink-0">
                      <MapPin className="w-6 h-6" />
                    </div>
                    <div>
                      <span className="text-[10px] font-mono tracking-wider uppercase text-slate-500 dark:text-slate-500">Base Location</span>
                      <p className={`text-sm sm:text-base font-semibold ${
                        darkMode ? 'text-white' : 'text-slate-800'
                      }`}>
                        Salem, Tamil Nadu, India
                      </p>
                    </div>
                  </div>

                </div>
              </div>

              {/* Social Channels buttons inside the left block */}
              <div className="pt-8 border-t border-slate-200/50 dark:border-white/5">
                <p className="text-xs font-mono text-slate-500 mb-4 text-left">Find me on professional platforms:</p>
                <div className="grid grid-cols-2 gap-4">
                  
                  <a
                    href={PERSONAL_INFO.socials.linkedin}
                    target="_blank"
                    referrerPolicy="no-referrer"
                    className={`flex items-center justify-center space-x-2 py-3 rounded-xl border font-semibold text-xs transition-all ${
                      darkMode
                        ? 'bg-white/5 border-white/10 hover:bg-white/10 text-white hover:border-blue-500/40'
                        : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200 hover:border-blue-500/40'
                    }`}
                  >
                    <Linkedin className="w-4 h-4 text-blue-500" />
                    <span>LinkedIn Profile</span>
                  </a>

                  <a
                    href={PERSONAL_INFO.socials.github}
                    target="_blank"
                    referrerPolicy="no-referrer"
                    className={`flex items-center justify-center space-x-2 py-3 rounded-xl border font-semibold text-xs transition-all ${
                      darkMode
                        ? 'bg-white/5 border-white/10 hover:bg-white/10 text-white hover:border-purple-500/40'
                        : 'bg-slate-100 border-slate-200 text-slate-700 hover:bg-slate-200 hover:border-purple-500/40'
                    }`}
                  >
                    <Github className="w-4 h-4 text-purple-400" />
                    <span>GitHub Space</span>
                  </a>

                </div>
              </div>

            </div>
          </div>

          {/* Right Side: Modern Interactive Contact Form (Lg: col 7) */}
          <div className="lg:col-span-7">
            <div className={`rounded-3xl p-6 sm:p-8 border h-full flex flex-col justify-center relative overflow-hidden ${
              darkMode
                ? 'bg-slate-900/40 border-white/10 text-slate-300'
                : 'bg-white border-slate-200 text-slate-700 shadow-xl shadow-slate-100/40'
            }`}>
              
              {/* Form Success Banner / Modal */}
              {submitted ? (
                <div className="flex flex-col items-center justify-center py-12 text-center animate-fade-in space-y-4">
                  <div className="w-16 h-16 rounded-full bg-emerald-500/10 border-2 border-emerald-500 flex items-center justify-center text-emerald-500 animate-bounce">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h3 className={`text-2xl font-bold ${darkMode ? 'text-white' : 'text-slate-800'}`}>
                    Message Sent Successfully!
                  </h3>
                  <p className="text-sm max-w-sm text-slate-400 leading-relaxed">
                    Thank you for reaching out! Sabari has received your message and will review it and reply within 24 hours.
                  </p>
                  <button
                    onClick={() => setSubmitted(false)}
                    className="inline-flex items-center justify-center px-5 py-2.5 rounded-xl font-semibold text-xs text-white bg-blue-600 hover:bg-blue-700 focus:outline-none transition-all mt-4"
                  >
                    <RefreshCw className="w-3.5 h-3.5 mr-1.5" />
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5 text-left">
                  
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                    {/* Name */}
                    <div className="space-y-1.5">
                      <label htmlFor="name-input" className="text-xs font-bold font-mono tracking-wider uppercase text-slate-400">
                        Your Full Name <span className="text-red-500">*</span>
                      </label>
                      <input
                        id="name-input"
                        type="text"
                        placeholder="John Doe"
                        value={name}
                        onChange={(e) => {
                          setName(e.target.value);
                          if (errors.name) setErrors({ ...errors, name: undefined });
                        }}
                        className={`w-full px-4 py-3 rounded-xl border text-sm font-medium transition-all focus:outline-none ${
                          errors.name
                            ? 'border-red-500 bg-red-500/5 focus:ring-1 focus:ring-red-500'
                            : darkMode
                            ? 'bg-[#050816]/75 border-white/10 text-white focus:border-blue-500'
                            : 'bg-slate-50 border-slate-200 text-slate-800 focus:border-blue-500'
                        }`}
                      />
                      {errors.name && (
                        <p className="text-red-500 font-mono text-[10px] flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5" /> {errors.name}
                        </p>
                      )}
                    </div>

                    {/* Email */}
                    <div className="space-y-1.5">
                      <label htmlFor="email-input" className="text-xs font-bold font-mono tracking-wider uppercase text-slate-400">
                        Email Address <span className="text-red-500">*</span>
                      </label>
                      <input
                        id="email-input"
                        type="email"
                        placeholder="john@example.com"
                        value={email}
                        onChange={(e) => {
                          setEmail(e.target.value);
                          if (errors.email) setErrors({ ...errors, email: undefined });
                        }}
                        className={`w-full px-4 py-3 rounded-xl border text-sm font-medium transition-all focus:outline-none ${
                          errors.email
                            ? 'border-red-500 bg-red-500/5 focus:ring-1 focus:ring-red-500'
                            : darkMode
                            ? 'bg-[#050816]/75 border-white/10 text-white focus:border-blue-500'
                            : 'bg-slate-50 border-slate-200 text-slate-800 focus:border-blue-500'
                        }`}
                      />
                      {errors.email && (
                        <p className="text-red-500 font-mono text-[10px] flex items-center gap-1">
                          <AlertCircle className="w-3.5 h-3.5" /> {errors.email}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Subject */}
                  <div className="space-y-1.5">
                    <label htmlFor="subject-input" className="text-xs font-bold font-mono tracking-wider uppercase text-slate-400">
                      Subject
                    </label>
                    <input
                      id="subject-input"
                      type="text"
                      placeholder="Internship / Proposal Discussion"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      className={`w-full px-4 py-3 rounded-xl border text-sm font-medium transition-all focus:outline-none ${
                        darkMode
                          ? 'bg-[#050816]/75 border-white/10 text-white focus:border-blue-500'
                          : 'bg-slate-50 border-slate-200 text-slate-800 focus:border-blue-500'
                      }`}
                    />
                  </div>

                  {/* Message */}
                  <div className="space-y-1.5">
                    <label htmlFor="message-input" className="text-xs font-bold font-mono tracking-wider uppercase text-slate-400">
                      Your Message <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      id="message-input"
                      rows={5}
                      placeholder="Hi Sabari, I would love to connect about an opportunity..."
                      value={message}
                      onChange={(e) => {
                        setMessage(e.target.value);
                        if (errors.message) setErrors({ ...errors, message: undefined });
                      }}
                      className={`w-full px-4 py-3 rounded-xl border text-sm font-medium transition-all focus:outline-none resize-none ${
                        errors.message
                          ? 'border-red-500 bg-red-500/5 focus:ring-1 focus:ring-red-500'
                          : darkMode
                          ? 'bg-[#050816]/75 border-white/10 text-white focus:border-blue-500'
                          : 'bg-slate-50 border-slate-200 text-slate-800 focus:border-blue-500'
                      }`}
                    />
                    {errors.message && (
                      <p className="text-red-500 font-mono text-[10px] flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5" /> {errors.message}
                      </p>
                    )}
                  </div>

                  {/* Glowing Submit Button */}
                  <button
                    id="contact-submit-btn"
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full flex items-center justify-center px-6 py-3.5 rounded-2xl font-bold text-white bg-gradient-to-r from-blue-500 to-purple-600 shadow-lg shadow-blue-500/20 hover:shadow-xl hover:shadow-purple-500/35 transition-all duration-300 hover:scale-[1.01] active:scale-95 glow-btn disabled:opacity-50 disabled:cursor-not-allowed focus:outline-none mt-4"
                  >
                    {isSubmitting ? (
                      <>
                        <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                        Routing Message Securely...
                      </>
                    ) : (
                      <>
                        <Send className="w-5 h-5 mr-2" />
                        Send Glowing Message
                      </>
                    )}
                  </button>

                </form>
              )}

            </div>
          </div>

        </div>
      </div>
    </section>
  );
}
